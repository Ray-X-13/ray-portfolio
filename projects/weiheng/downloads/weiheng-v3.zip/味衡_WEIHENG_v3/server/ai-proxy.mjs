/**
 * Optional OpenAI-compatible recommendation proxy.
 *
 * This file is not needed for the local-rule demo. When configured with a
 * server-side key, it lets the frontend call a real model without exposing the
 * key. It intentionally returns only meals from the catalog supplied by the
 * client and rejects allergen conflicts deterministically.
 */
import { createServer } from "node:http";

const port = Number(process.env.PORT || 8787);
const allowedOrigin = process.env.ALLOWED_ORIGIN || "http://127.0.0.1:5173";
const apiKey = process.env.AI_API_KEY;
const baseUrl = (process.env.AI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, "");
const model = process.env.AI_MODEL || "gpt-4.1-mini";

const normalize = (value) => String(value).toLowerCase().replace(/\s+/g, "");

function isSafe(meal, taboos) {
  const searchable = [meal.name, ...(meal.ingredients || []), ...(meal.allergens || [])].map(normalize);
  return !taboos.some((taboo) => {
    const safeTaboo = normalize(taboo);
    return searchable.some((value) => value.includes(safeTaboo) || safeTaboo.includes(value));
  });
}

function sendJson(response, status, payload) {
  response.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": allowedOrigin,
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Cache-Control": "no-store",
  });
  response.end(JSON.stringify(payload));
}

function parseModelJson(content) {
  const cleaned = content.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start < 0 || end <= start) throw new Error("Model did not return a JSON object");
  return JSON.parse(cleaned.slice(start, end + 1));
}

async function readBody(request) {
  let size = 0;
  const chunks = [];
  for await (const chunk of request) {
    size += chunk.length;
    if (size > 1_000_000) throw new Error("Request body is too large");
    chunks.push(chunk);
  }
  return JSON.parse(Buffer.concat(chunks).toString("utf8"));
}

const server = createServer(async (request, response) => {
  if (request.method === "OPTIONS") {
    sendJson(response, 204, {});
    return;
  }

  if (request.method !== "POST" || request.url !== "/api/recommend") {
    sendJson(response, 404, { error: "Not found" });
    return;
  }

  if (!apiKey) {
    sendJson(response, 503, {
      error: "AI provider is not configured. The frontend will use local rules.",
    });
    return;
  }

  try {
    const { input, settings, catalog, recentMeals = [], memories = [] } = await readBody(request);
    if (!Array.isArray(catalog) || !catalog.length) {
      throw new Error("A meal catalog is required");
    }

    const safeCatalog = catalog.filter((meal) => isSafe(meal, settings?.taboos || []));
    if (!safeCatalog.length) {
      sendJson(response, 422, { error: "No meal satisfies the saved allergy constraints" });
      return;
    }

    const prompt = [
      "You are the meal decision layer of WeiHeng, a consumer nutrition assistant.",
      "Choose exactly one meal from the supplied catalog. Respect allergy/taboo exclusions as hard constraints.",
      "Do not provide medical diagnosis, treatment, exact measurement, or invented nutrition values.",
      "The catalog nutrition values are estimates and must be returned unchanged through the selected meal id.",
      "Return JSON only with this schema:",
      '{"mealId":"catalog id","score":0-100,"reasons":["2-3 concise Chinese reasons"],"fitLabels":["up to 3 short Chinese labels"],"alternativeIds":["up to 2 other catalog ids"]}',
      `Current conditions: ${JSON.stringify(input)}`,
      `Saved preferences: ${JSON.stringify(settings)}`,
      `User-confirmed long-term memories: ${JSON.stringify(memories)}`,
      `Recent meals: ${JSON.stringify(recentMeals)}`,
      `Allowed catalog: ${JSON.stringify(safeCatalog)}`,
    ].join("\n");

    const providerResponse = await fetch(`${baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        temperature: 0.35,
        response_format: { type: "json_object" },
        messages: [
          {
            role: "system",
            content: "Return a single valid JSON object and no prose outside it.",
          },
          { role: "user", content: prompt },
        ],
      }),
    });

    if (!providerResponse.ok) {
      throw new Error(`Model provider returned ${providerResponse.status}`);
    }

    const providerPayload = await providerResponse.json();
    const content = providerPayload?.choices?.[0]?.message?.content;
    if (typeof content !== "string") throw new Error("Model response did not contain content");
    const decision = parseModelJson(content);
    const selected = safeCatalog.find((meal) => meal.id === decision.mealId);
    if (!selected) throw new Error("Model selected a meal outside the safe catalog");

    const alternatives = (decision.alternativeIds || [])
      .map((id) => safeCatalog.find((meal) => meal.id === id))
      .filter((meal) => meal && meal.id !== selected.id)
      .slice(0, 2);

    sendJson(response, 200, {
      meal: selected,
      score: Math.min(98, Math.max(50, Number(decision.score) || 80)),
      reasons: Array.isArray(decision.reasons) ? decision.reasons.slice(0, 3).map(String) : [],
      fitLabels: Array.isArray(decision.fitLabels) ? decision.fitLabels.slice(0, 3).map(String) : [],
      alternatives,
      source: "api",
    });
  } catch (error) {
    console.error(error);
    sendJson(response, 502, { error: "The AI recommendation could not be generated safely." });
  }
});

server.listen(port, "127.0.0.1", () => {
  console.log(`WeiHeng AI proxy listening on http://127.0.0.1:${port}`);
});
