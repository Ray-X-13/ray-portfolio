import { chromium } from "playwright-core";
import { mkdir } from "node:fs/promises";
import { fileURLToPath } from "node:url";

const baseUrl = process.env.WEIHENG_URL ?? "http://127.0.0.1:5173/";
const evidenceDir = new URL("../evidence/", import.meta.url);
await mkdir(evidenceDir, { recursive: true });

const browser = await chromium.launch({
  executablePath:
    process.env.CHROME_PATH || "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
  headless: true,
});

const context = await browser.newContext({
  viewport: { width: 1440, height: 1000 },
  deviceScaleFactor: 1,
  locale: "zh-CN",
});
const page = await context.newPage();
const checks = [];
const browserErrors = [];
page.on("pageerror", (error) => browserErrors.push(error.message));
page.on("console", (message) => {
  if (message.type() === "error") browserErrors.push(message.text());
});

const check = (name, condition, detail = "") => {
  if (!condition) throw new Error(`FAILED: ${name}${detail ? ` — ${detail}` : ""}`);
  checks.push({ name, passed: true });
};

const visibleButton = (name) => page.getByRole("button", { name }).first();
const screenshotPath = (name) => fileURLToPath(new URL(name, evidenceDir));
const settleVisuals = async () => {
  await page.waitForTimeout(700);
  await page.evaluate(() => {
    document.documentElement.style.scrollBehavior = "auto";
    window.scrollTo(0, 0);
    if (document.activeElement instanceof HTMLElement) document.activeElement.blur();
    document.getAnimations().forEach((animation) => animation.finish());
    if (!document.getElementById("qa-evidence-style")) {
      const style = document.createElement("style");
      style.id = "qa-evidence-style";
      style.textContent = ".skip-link{visibility:hidden!important}";
      document.head.appendChild(style);
    }
  });
  await page.waitForTimeout(50);
};

try {
  await page.goto(baseUrl, { waitUntil: "networkidle" });
  await page.evaluate(() => localStorage.clear());
  await page.reload({ waitUntil: "networkidle" });

  check("首页加载", await page.getByRole("heading", { name: /从此刻的条件里/ }).isVisible());
  check("示例数据边界可见", await page.getByText("示例餐盘 · 可直接修改").isVisible());
  await settleVisuals();
  await page.screenshot({ path: screenshotPath("home-desktop.png"), fullPage: true });

  await visibleButton(/决定晚餐/).click();
  await page.locator("textarea").first().fill("想吃热食，简单一点");
  await visibleButton(/生成一餐建议/).click();
  await page.locator(".meal-result-card").waitFor({ state: "visible" });
  check("推荐结果生成", await page.locator(".meal-result-card").isVisible());
  check("推荐来源透明", await page.getByText("本地规则推荐").isVisible());
  check("推荐包含理由", await page.getByText("为什么是它").isVisible());
  await settleVisuals();
  await page.screenshot({ path: screenshotPath("decision-desktop.png"), fullPage: true });

  await visibleButton("就吃这一餐").click();
  await page.locator(".record-modal").waitFor({ state: "visible" });
  const titleInput = page.locator(".modal-title-field input");
  await titleInput.fill("验收测试餐");
  await visibleButton("保存记录").click();
  await page.locator(".record-modal").waitFor({ state: "hidden" });

  await page.locator(".sidebar-nav button").filter({ hasText: "饮食记录" }).click();
  check("推荐可转为饮食记录", await page.getByRole("heading", { name: "验收测试餐", exact: true }).isVisible());
  check("记录页显示新记录", await page.getByRole("heading", { name: "验收测试餐", exact: true }).isVisible());
  await settleVisuals();
  await page.screenshot({ path: screenshotPath("records-desktop.png"), fullPage: true });
  await page.reload({ waitUntil: "networkidle" });
  check("刷新后记录保留", await page.getByRole("heading", { name: "验收测试餐", exact: true }).isVisible());

  await page.getByRole("button", { name: "编辑验收测试餐" }).click();
  await page.locator(".modal-title-field input").fill("验收测试餐已修改");
  await visibleButton("保存修改").click();
  check("记录支持修改", await page.getByRole("heading", { name: "验收测试餐已修改", exact: true }).isVisible());

  await visibleButton("添加记录").click();
  await page.locator(".modal-title-field input").fill("待删除测试记录");
  await visibleButton("保存记录").click();
  await page.getByRole("button", { name: "删除待删除测试记录" }).click();
  await visibleButton("删除").click();
  check("记录支持删除", (await page.getByRole("heading", { name: "待删除测试记录", exact: true }).count()) === 0);

  await page.locator(".sidebar-nav button").filter({ hasText: "反馈与记忆" }).click();
  check("反馈看板渲染", await page.getByText("七日记录节奏").isVisible());
  check("营养估算免责声明", await page.getByText(/所有营养数据均为/).isVisible());
  check("餐后反馈形成记忆候选", await page.locator(".memory-candidate").first().isVisible());
  await settleVisuals();
  await page.screenshot({ path: screenshotPath("memory-desktop.png"), fullPage: true });
  await page.getByRole("button", { name: "写入记忆" }).first().click();
  check("记忆候选可确认", (await page.locator(".memory-count").innerText()).includes("1"));
  check("记忆可影响推荐依据", (await page.locator(".memory-count").innerText()).includes("已确认"));
  await settleVisuals();
  await page.screenshot({ path: screenshotPath("insights-desktop.png"), fullPage: true });

  await page.locator(".sidebar-nav button").filter({ hasText: "决定一餐" }).click();
  await page.getByRole("button", { name: /用当前条件试试/ }).click();
  await page.locator(".meal-result-card").waitFor({ state: "visible" });
  check(
    "长期记忆进入下一次推荐",
    (await page.locator(".meal-result-card").innerText()).includes("长期记忆参与判断"),
  );
  await page.locator(".sidebar-nav button").filter({ hasText: "反馈与记忆" }).click();
  await page.getByRole("button", { name: /停用记忆/ }).first().click();
  check("已确认记忆可停用", (await page.locator(".memory-count").innerText()).includes("0 条已确认"));

  await page.locator(".sidebar-nav button").filter({ hasText: "个性设置" }).click();
  await page.getByRole("button", { name: /增加蛋白质/ }).click();
  await page.getByRole("button", { name: "保存设置" }).click();
  check("设置保存反馈", await page.getByText(/设置已保存/).isVisible());
  await settleVisuals();
  await page.screenshot({ path: screenshotPath("settings-desktop.png"), fullPage: true });
  await page.locator(".sidebar-nav button").filter({ hasText: "决定一餐" }).click();
  check(
    "设置影响下一次推荐表单",
    await page.locator(".goal-choice-grid button.is-selected").filter({ hasText: "增加蛋白质" }).isVisible(),
  );

  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(baseUrl, { waitUntil: "networkidle" });
  check("移动端底部导航", await page.locator(".mobile-nav").isVisible());
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  check("移动端无横向溢出", overflow <= 1, `overflow=${overflow}`);
  await settleVisuals();
  await page.screenshot({ path: screenshotPath("home-mobile.png") });
  await page.locator(".mobile-nav button").filter({ hasText: "决定" }).click();
  await page.getByRole("button", { name: /用当前条件试试/ }).click();
  await page.locator(".meal-result-card").waitFor({ state: "visible" });
  await page.locator(".meal-result-card").scrollIntoViewIfNeeded();
  await page.waitForTimeout(600);
  await page.screenshot({ path: screenshotPath("decision-mobile.png") });
  check("移动端推荐可用", await page.getByText("本地规则推荐").isVisible());
  await page.locator(".mobile-nav button").filter({ hasText: "反馈与记忆" }).click();
  check("移动端记忆入口可用", await page.locator(".memory-panel").isVisible());
  const memoryOverflow = await page.evaluate(
    () => document.documentElement.scrollWidth - window.innerWidth,
  );
  check("移动端记忆页无横向溢出", memoryOverflow <= 1, `overflow=${memoryOverflow}`);
  await page.locator(".memory-panel").screenshot({
    path: screenshotPath("memory-mobile.png"),
  });

  console.log(JSON.stringify({ baseUrl, checks, browserErrors, status: "passed" }, null, 2));
} catch (error) {
  await page.screenshot({ path: screenshotPath("failure.png"), fullPage: true }).catch(() => {});
  console.error(JSON.stringify({ checks, browserErrors, body: await page.locator("body").innerText().catch(() => "") }, null, 2));
  throw error;
} finally {
  await browser.close();
}
