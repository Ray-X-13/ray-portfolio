export type Page = "home" | "decide" | "records" | "insights" | "settings";

export type Goal = "balanced" | "highProtein" | "fatLoss" | "energy";

export type MealType = "早餐" | "午餐" | "晚餐" | "加餐";

export type Nutrition = {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
};

export type Meal = {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  minutes: number;
  cost: number;
  ingredients: string[];
  steps: string[];
  nutrition: Nutrition;
  tags: string[];
  goals: Goal[];
  vegetarian: boolean;
  allergens: string[];
  context: "home" | "outside" | "either";
  accent: "tomato" | "olive" | "mustard" | "ink";
};

export type UserSettings = {
  displayName: string;
  preferences: string[];
  taboos: string[];
  budget: number;
  defaultMinutes: number;
  commonIngredients: string[];
  goal: Goal;
};

export type DecisionInput = {
  craving: string;
  ingredients: string[];
  budget: number;
  minutes: number;
  goal: Goal;
  appetite: 1 | 2 | 3 | 4 | 5;
  context: "home" | "outside";
};

export type Recommendation = {
  meal: Meal;
  score: number;
  reasons: string[];
  fitLabels: string[];
  alternatives: Meal[];
  source: "local" | "api";
};

export type MealRecord = {
  id: string;
  date: string;
  mealType: MealType;
  title: string;
  ingredients: string[];
  note: string;
  nutrition: Nutrition;
  satisfaction?: "good" | "okay" | "poor";
  sourceTags?: string[];
  createdAt: string;
  origin: "demo" | "manual" | "recommendation";
};

export type MemoryEntry = {
  id: string;
  kind: "preference" | "avoidance";
  tag: string;
  statement: string;
  detail: string;
  evidenceRecordIds: string[];
  status: "candidate" | "confirmed" | "dismissed";
  updatedAt: string;
};
