export function BrandMark({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`brand-lockup${compact ? " is-compact" : ""}`} aria-label="味衡 WEIHENG">
      <span className="brand-symbol" aria-hidden="true">
        <svg viewBox="0 0 42 42">
          <circle cx="21" cy="21" r="16.5" />
          <path d="M13 14.5h16M18 14.5v16M24 14.5v16" />
          <circle className="brand-symbol-dot" cx="33.5" cy="8.5" r="2.5" />
        </svg>
      </span>
      <span className="brand-words">
        <strong>味衡</strong>
        <small>WEIHENG</small>
      </span>
    </div>
  );
}
