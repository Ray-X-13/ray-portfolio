import { useEffect, useState } from "react";
import { CalendarDays, Check, Info, Minus, ThumbsDown, ThumbsUp, X } from "lucide-react";
import type { MealRecord, MealType, Nutrition } from "../types";
import { emptyNutrition } from "../lib/nutrition";
import { localDate } from "../lib/storage";

type RecordModalProps = {
  draft: Partial<MealRecord> | null;
  onClose: () => void;
  onSave: (record: MealRecord) => void;
};

const mealTypes: MealType[] = ["早餐", "午餐", "晚餐", "加餐"];

function inferMealType(): MealType {
  const hour = new Date().getHours();
  if (hour < 10) return "早餐";
  if (hour < 15) return "午餐";
  if (hour < 21) return "晚餐";
  return "加餐";
}

function makeId() {
  return typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : `record-${Date.now()}`;
}

export function RecordModal({ draft, onClose, onSave }: RecordModalProps) {
  const isOpen = draft !== null;
  const [title, setTitle] = useState("");
  const [date, setDate] = useState(localDate());
  const [mealType, setMealType] = useState<MealType>(inferMealType);
  const [ingredients, setIngredients] = useState("");
  const [note, setNote] = useState("");
  const [nutrition, setNutrition] = useState<Nutrition>(emptyNutrition);
  const [error, setError] = useState("");
  const [existingId, setExistingId] = useState<string | undefined>();
  const [origin, setOrigin] = useState<MealRecord["origin"]>("manual");
  const [satisfaction, setSatisfaction] = useState<NonNullable<MealRecord["satisfaction"]>>("good");
  const [sourceTags, setSourceTags] = useState<string[]>([]);
  const [createdAt, setCreatedAt] = useState("");

  useEffect(() => {
    if (!draft) return;
    setTitle(draft.title ?? "");
    setDate(draft.date ?? localDate());
    setMealType(draft.mealType ?? inferMealType());
    setIngredients(draft.ingredients?.join("、") ?? "");
    setNote(draft.note ?? "");
    setNutrition(draft.nutrition ? { ...draft.nutrition } : emptyNutrition());
    setExistingId(draft.id);
    setOrigin(draft.origin ?? "manual");
    setSatisfaction(draft.satisfaction ?? "good");
    setSourceTags(draft.sourceTags ?? []);
    setCreatedAt(draft.createdAt ?? new Date().toISOString());
    setError("");
  }, [draft]);

  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKeyDown);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKeyDown);
      document.body.style.overflow = "";
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const setNutritionField = (key: keyof Nutrition, value: string) => {
    setNutrition((previous) => ({ ...previous, [key]: Math.max(0, Number(value) || 0) }));
  };

  const submit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!title.trim()) {
      setError("请填写餐食名称。");
      return;
    }
    if (!date) {
      setError("请选择记录日期。");
      return;
    }
    onSave({
      id: existingId ?? makeId(),
      title: title.trim(),
      date,
      mealType,
      ingredients: ingredients
        .split(/[、,，]/)
        .map((item) => item.trim())
        .filter(Boolean),
      note: note.trim(),
      nutrition,
      satisfaction,
      sourceTags,
      createdAt,
      origin,
    });
  };

  return (
    <div
      className="modal-backdrop"
      role="presentation"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <section
        className="record-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="record-modal-title"
      >
        <header className="modal-header">
          <div>
            <span className="micro-label">餐后记录</span>
            <h2 id="record-modal-title">{existingId ? "修改饮食记录" : "记下这一餐"}</h2>
            <p>保留真实感受，比追求精确数字更有用。</p>
          </div>
          <button className="modal-close" type="button" onClick={onClose} aria-label="关闭">
            <X size={20} />
          </button>
        </header>

        <form onSubmit={submit}>
          <div className="modal-body">
            <label className="field-block modal-title-field">
              <span className="field-label">吃了什么</span>
              <input
                autoFocus
                value={title}
                onChange={(event) => setTitle(event.target.value)}
                placeholder="例如：番茄滑蛋青菜饭"
                maxLength={40}
              />
            </label>

            <div className="modal-fields-row">
              <label className="field-block">
                <span className="field-label"><CalendarDays size={15} />日期</span>
                <input
                  type="date"
                  value={date}
                  onChange={(event) => setDate(event.target.value)}
                />
              </label>
              <div className="field-block">
                <span className="field-label">餐次</span>
                <div className="modal-meal-types">
                  {mealTypes.map((type) => (
                    <button
                      key={type}
                      type="button"
                      className={mealType === type ? "is-active" : ""}
                      onClick={() => setMealType(type)}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <label className="field-block">
              <span className="field-label">主要食材 <small>用逗号或顿号分隔</small></span>
              <input
                value={ingredients}
                onChange={(event) => setIngredients(event.target.value)}
                placeholder="鸡蛋、番茄、青菜、米饭"
              />
            </label>

            <div className="after-meal-feedback">
              <div>
                <span className="field-label">这餐符合你的预期吗？</span>
                <p>一个轻量反馈，用来判断是否值得形成长期偏好。</p>
              </div>
              <div className="satisfaction-options" role="group" aria-label="餐后感受">
                <button
                  type="button"
                  className={satisfaction === "good" ? "is-selected" : ""}
                  onClick={() => setSatisfaction("good")}
                >
                  <ThumbsUp size={16} />
                  还想再吃
                </button>
                <button
                  type="button"
                  className={satisfaction === "okay" ? "is-selected" : ""}
                  onClick={() => setSatisfaction("okay")}
                >
                  <Minus size={16} />
                  一般
                </button>
                <button
                  type="button"
                  className={satisfaction === "poor" ? "is-selected" : ""}
                  onClick={() => setSatisfaction("poor")}
                >
                  <ThumbsDown size={16} />
                  不太合适
                </button>
              </div>
            </div>

            <div className="nutrition-form">
              <div className="nutrition-form-heading">
                <div>
                  <span className="field-label">营养估算 <small>可选</small></span>
                  <p>如果由味衡建议转记录，数字已自动带入。</p>
                </div>
                <Info size={16} aria-hidden="true" />
              </div>
              <div className="nutrition-input-grid">
                <label><span>热量</span><input type="number" min="0" step="1" value={nutrition.calories} onChange={(event) => setNutritionField("calories", event.target.value)} /><small>kcal</small></label>
                <label><span>蛋白质</span><input type="number" min="0" step="0.1" value={nutrition.protein} onChange={(event) => setNutritionField("protein", event.target.value)} /><small>g</small></label>
                <label><span>碳水</span><input type="number" min="0" step="0.1" value={nutrition.carbs} onChange={(event) => setNutritionField("carbs", event.target.value)} /><small>g</small></label>
                <label><span>脂肪</span><input type="number" min="0" step="0.1" value={nutrition.fat} onChange={(event) => setNutritionField("fat", event.target.value)} /><small>g</small></label>
                <label><span>膳食纤维</span><input type="number" min="0" step="0.1" value={nutrition.fiber} onChange={(event) => setNutritionField("fiber", event.target.value)} /><small>g</small></label>
              </div>
            </div>

            <label className="field-block">
              <span className="field-label">这一餐的感受 <small>可选</small></span>
              <textarea
                rows={3}
                value={note}
                onChange={(event) => setNote(event.target.value)}
                placeholder="例如：七分饱，做法简单，下次还可以再吃。"
              />
            </label>
            {error ? <p className="form-error" role="alert">{error}</p> : null}
          </div>

          <footer className="modal-footer">
            <span><Info size={14} />所有营养数字均按估算值记录</span>
            <div>
              <button className="button button-quiet" type="button" onClick={onClose}>取消</button>
              <button className="button button-primary" type="submit">
                <Check size={17} />
                {existingId ? "保存修改" : "保存记录"}
              </button>
            </div>
          </footer>
        </form>
      </section>
    </div>
  );
}
