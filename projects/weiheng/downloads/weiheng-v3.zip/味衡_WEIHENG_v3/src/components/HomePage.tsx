import {
  ArrowUpRight,
  BookOpenText,
  Brain,
  ChevronRight,
  Clock3,
  Plus,
  Sparkles,
} from "lucide-react";
import { goalLabels } from "../data/meals";
import { getLastSevenDays, getTodayRecords, sumNutrition } from "../lib/nutrition";
import type { MealRecord, MemoryEntry, Page, UserSettings } from "../types";

type HomePageProps = {
  settings: UserSettings;
  records: MealRecord[];
  memories: MemoryEntry[];
  onNavigate: (page: Page) => void;
  onAddRecord: () => void;
};

const dateFormatter = new Intl.DateTimeFormat("zh-CN", {
  month: "long",
  day: "numeric",
  weekday: "long",
});

function getGreeting() {
  const hour = new Date().getHours();
  if (hour < 11) return "早上好";
  if (hour < 14) return "中午好";
  if (hour < 18) return "下午好";
  return "晚上好";
}

function getNextMeal(records: MealRecord[]): MealRecord["mealType"] {
  if (!records.some((record) => record.mealType === "早餐")) return "早餐";
  if (!records.some((record) => record.mealType === "午餐")) return "午餐";
  if (!records.some((record) => record.mealType === "晚餐")) return "晚餐";
  return "加餐";
}

export function HomePage({
  settings,
  records,
  memories,
  onNavigate,
  onAddRecord,
}: HomePageProps) {
  const today = getTodayRecords(records);
  const nutrition = sumNutrition(today);
  const week = getLastSevenDays(records);
  const nextMeal = getNextMeal(today);
  const candidates = memories.filter((memory) => memory.status === "candidate");
  const sampleMode = today.length > 0 && today.every((record) => record.origin === "demo");
  const maxCalories = Math.max(1, ...week.map((day) => day.nutrition.calories));
  const currentMeal =
    today.find((record) => record.mealType === nextMeal) ??
    today.find((record) => record.mealType === "晚餐") ??
    today.at(-1);

  return (
    <div className="page home-v3">
      <header className="v3-topbar">
        <div>
          <span>{dateFormatter.format(new Date())}</span>
          <h1>{getGreeting()}，{settings.displayName}</h1>
        </div>
        <button type="button" onClick={() => onNavigate("settings")} aria-label="打开个性设置">
          {settings.displayName.slice(0, 1)}
        </button>
      </header>

      <section className="home-command">
        <div className="home-command-copy">
          <span className="v3-status">
            <i aria-hidden="true" />
            {sampleMode ? "示例餐盘 · 可直接修改" : `${today.length} 餐已记录`}
          </span>
          <h2>
            从此刻的条件里，
            <br />
            选一份能完成的餐。
          </h2>
          <p>
            {nextMeal === "加餐"
              ? "今天的三餐已经记录，可以继续补充真实感受。"
              : `${nextMeal}还没有着落。把时间、预算和手边食材交给味衡，先得到一张可执行的餐卡。`}
          </p>
          <div className="home-context-pills">
            <span><Clock3 size={14} />{settings.defaultMinutes} 分钟</span>
            <span>¥{settings.budget} 以内</span>
            <span>{goalLabels[settings.goal]}</span>
          </div>
          <div className="home-command-actions">
            <button className="button button-primary" type="button" onClick={() => onNavigate("decide")}>
              <Sparkles size={18} />
              决定{nextMeal}
              <ArrowUpRight size={17} />
            </button>
            <button className="button button-secondary" type="button" onClick={onAddRecord}>
              <Plus size={17} />
              记录已吃
            </button>
          </div>
        </div>

        <div className="home-plate-visual" aria-hidden="true">
          <span className="v3-orbit orbit-outer" />
          <span className="v3-orbit orbit-inner" />
          <span className="v3-plate">
            <i className="food-shape-1" />
            <i className="food-shape-2" />
            <i className="food-shape-3" />
            <i className="food-shape-4" />
          </span>
          <span className="v3-plate-label label-next">下一餐</span>
          <span className="v3-plate-label label-context">上下文决策</span>
          <span className="v3-plate-label label-memory">记忆已连接</span>
        </div>
      </section>

      <section className="home-dashboard">
        <article className="v3-day-card">
          <div className="v3-section-head">
            <div>
              <span>今天的餐盘</span>
              <h2>{sampleMode ? "示例节奏" : "今天吃得怎么样"}</h2>
            </div>
            <button type="button" onClick={() => onNavigate("records")}>
              全部记录 <ChevronRight size={15} />
            </button>
          </div>

          <div className="v3-meal-timeline">
            {(["早餐", "午餐", "晚餐", "加餐"] as const).map((slot) => {
              const record = today.find((entry) => entry.mealType === slot);
              if (slot === "加餐" && !record) return null;
              return (
                <button
                  type="button"
                  key={slot}
                  className={record ? "is-recorded" : ""}
                  onClick={() => (record ? onNavigate("records") : onAddRecord())}
                >
                  <span className="timeline-dot" aria-hidden="true" />
                  <span className="timeline-label">{slot}</span>
                  <strong>{record?.title ?? "等待记录"}</strong>
                  <small>{record ? `${record.nutrition.calories} kcal 估算` : "点此补充"}</small>
                </button>
              );
            })}
          </div>

          <div className="v3-day-summary">
            <div><strong>{today.length}</strong><span>条记录</span></div>
            <div><strong>{nutrition.calories || "—"}</strong><span>热量估算</span></div>
            <div><strong>{nutrition.protein.toFixed(0)}g</strong><span>蛋白质估算</span></div>
          </div>
        </article>

        <article className="v3-memory-card">
          <span className="v3-card-icon"><Brain size={20} /></span>
          <span className="v3-kicker">长期记忆</span>
          <h2>
            {candidates.length
              ? `“${candidates[0].tag}”这条偏好，要记住吗？`
              : "味衡不会替你擅自下结论。"}
          </h2>
          <p>
            {candidates.length
              ? `${candidates.length} 条餐后信号等待确认。确认后才会影响下一次推荐。`
              : "记录一餐并告诉味衡真实感受，新的偏好会先成为候选，再由你决定是否保留。"}
          </p>
          <button type="button" onClick={() => onNavigate("insights")}>
            {candidates.length ? "确认记忆" : "查看记忆机制"}
            <ArrowUpRight size={15} />
          </button>
        </article>
      </section>

      <section className="home-bottom-grid">
        <article className="v3-rhythm">
          <div className="v3-section-head">
            <div>
              <span>近七天</span>
              <h2>饮食节奏</h2>
            </div>
            <BookOpenText size={19} />
          </div>
          <div className="v3-week-chart">
            {week.map((day, index) => (
              <div key={day.date}>
                <span className="v3-bar-track">
                  <i
                    className={index === 6 ? "is-today" : ""}
                    style={{ height: `${Math.max(4, (day.nutrition.calories / maxCalories) * 100)}%` }}
                  />
                </span>
                <small>{day.label}</small>
              </div>
            ))}
          </div>
          <p>热量与营养均为餐食组合的区间估算，只用于观察节奏。</p>
        </article>

        <article className="v3-last-meal">
          <div className="v3-section-head">
            <div>
              <span>最近一餐</span>
              <h2>{currentMeal?.title ?? "从第一餐开始"}</h2>
            </div>
            <span className="v3-meal-type">{currentMeal?.mealType ?? "待记录"}</span>
          </div>
          <div className="v3-food-notes">
            {currentMeal?.ingredients.slice(0, 4).map((ingredient) => (
              <span key={ingredient}>{ingredient}</span>
            ))}
          </div>
          <button type="button" onClick={() => onNavigate("records")}>
            回看这一餐 <ChevronRight size={15} />
          </button>
        </article>
      </section>
    </div>
  );
}
