import {
  BarChart3,
  BookOpenText,
  CircleUserRound,
  Home,
  Settings2,
  Sparkles,
} from "lucide-react";
import type { Page } from "../types";
import { BrandMark } from "./BrandMark";

const navigation: Array<{
  page: Page;
  label: string;
  caption: string;
  icon: typeof Home;
}> = [
  { page: "home", label: "今日", caption: "今天", icon: Home },
  { page: "decide", label: "决定一餐", caption: "取舍", icon: Sparkles },
  { page: "records", label: "饮食记录", caption: "回看", icon: BookOpenText },
  { page: "insights", label: "反馈与记忆", caption: "记忆", icon: BarChart3 },
  { page: "settings", label: "个性设置", caption: "边界", icon: Settings2 },
];

type LayoutProps = {
  page: Page;
  displayName: string;
  onNavigate: (page: Page) => void;
  children: React.ReactNode;
};

export function Layout({ page, displayName, onNavigate, children }: LayoutProps) {
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-top">
          <button className="brand-button" type="button" onClick={() => onNavigate("home")}>
            <BrandMark />
          </button>
          <p className="brand-line">Personal nutrition decisions.</p>
        </div>

        <nav className="sidebar-nav" aria-label="主要导航">
          {navigation.map((item, index) => {
            const Icon = item.icon;
            return (
              <button
                key={item.page}
                type="button"
                className={`nav-item${page === item.page ? " is-active" : ""}`}
                onClick={() => onNavigate(item.page)}
                aria-current={page === item.page ? "page" : undefined}
              >
                <span className="nav-index">0{index + 1}</span>
                <Icon size={18} strokeWidth={1.7} aria-hidden="true" />
                <span>{item.label}</span>
                <small>{item.caption}</small>
              </button>
            );
          })}
        </nav>

        <div className="sidebar-bottom">
          <button
            type="button"
            className="profile-chip"
            onClick={() => onNavigate("settings")}
          >
            <span className="profile-avatar">
              <CircleUserRound size={22} strokeWidth={1.5} aria-hidden="true" />
            </span>
            <span>
              <strong>{displayName}</strong>
              <small>饮食偏好已启用</small>
            </span>
            <i aria-hidden="true" />
          </button>
          <p className="local-note">
            <span aria-hidden="true" />
            数据仅保存在本机浏览器
          </p>
        </div>
      </aside>

      <header className="mobile-header">
        <button className="brand-button" type="button" onClick={() => onNavigate("home")}>
          <BrandMark compact />
        </button>
        <button
          className="mobile-profile"
          type="button"
          onClick={() => onNavigate("settings")}
          aria-label="打开个性设置"
        >
          {displayName.slice(0, 1)}
        </button>
      </header>

      <main className="app-main" id="main-content">
        {children}
      </main>

      <nav className="mobile-nav" aria-label="移动端导航">
        {navigation.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.page}
              type="button"
              className={page === item.page ? "is-active" : ""}
              onClick={() => onNavigate(item.page)}
              aria-current={page === item.page ? "page" : undefined}
            >
              <Icon size={20} strokeWidth={1.7} aria-hidden="true" />
              <span>{item.label.replace("一餐", "")}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}
