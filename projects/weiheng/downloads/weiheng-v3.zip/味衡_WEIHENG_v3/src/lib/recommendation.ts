import { meals } from "../data/meals";
import type { DecisionInput, Meal, MemoryEntry, Recommendation, UserSettings } from "../types";
import { describeMemoryInfluence, memorySignalForMeal } from "./memory";

const normalize = (value: string) => value.trim().toLowerCase().replace(/\s+/g, "");

const includesAny = (source: string, needles: string[]) =>
  needles.some((needle) => source.includes(normalize(needle)) || normalize(needle).includes(source));

export function isMealSafe(meal: Meal, taboos: string[], vegetarian = false): boolean {
  const searchable = [
    meal.name,
    ...meal.ingredients,
    ...meal.allergens,
  ].map(normalize);

  const conflicts = taboos.filter((taboo) => {
    const safeTaboo = normalize(taboo);
    return searchable.some((value) => value.includes(safeTaboo) || safeTaboo.includes(value));
  });

  return conflicts.length === 0 && (!vegetarian || meal.vegetarian);
}

type ScoredMeal = {
  meal: Meal;
  score: number;
  reasons: string[];
  fitLabels: string[];
};

export function rankMeals(
  input: DecisionInput,
  settings: UserSettings,
  recentMeals: string[] = [],
  memories: MemoryEntry[] = [],
): ScoredMeal[] {
  const availableIngredients = Array.from(
    new Set([...settings.commonIngredients, ...input.ingredients]),
  );
  const preferenceSet = new Set([...settings.preferences, input.craving].filter(Boolean));
  const tabooSet = [...settings.taboos];
  const isVegetarian = settings.preferences.includes("素食");

  return meals
    .filter((meal) => isMealSafe(meal, tabooSet, isVegetarian))
    .filter((meal) => input.context === "home" || meal.context !== "home")
    .map((meal) => {
      let score = 36;
      const reasons: string[] = [];
      const fitLabels: string[] = [];

      const usedIngredients = meal.ingredients.filter((ingredient) =>
        availableIngredients.some(
          (available) =>
            normalize(ingredient).includes(normalize(available)) ||
            normalize(available).includes(normalize(ingredient)),
        ),
      );

      if (usedIngredients.length) {
        score += Math.min(22, usedIngredients.length * 6);
        fitLabels.push(`${usedIngredients.length} 项食材可用`);
        reasons.push(
          usedIngredients.length >= 3
            ? `现有食材覆盖度高，${usedIngredients.slice(0, 3).join("、")}可以直接用上。`
            : `可以用上现有的${usedIngredients.join("、")}，减少额外采购。`,
        );
      }

      if (meal.minutes <= input.minutes) {
        score += 16 - (input.minutes - meal.minutes) * 0.08;
        fitLabels.push(`${meal.minutes} 分钟内可完成`);
        reasons.push(`制作约 ${meal.minutes} 分钟，符合你留给这一餐的 ${input.minutes} 分钟。`);
      } else {
        score -= (meal.minutes - input.minutes) * 2.4;
      }

      if (meal.cost <= input.budget) {
        score += 12 - (input.budget - meal.cost) * 0.04;
        fitLabels.push(`约 ¥${meal.cost}`);
      } else {
        score -= (meal.cost - input.budget) * 1.2;
      }

      if (meal.goals.includes(input.goal)) {
        score += 13;
        reasons.push("营养结构与当前饮食目标一致，作为一餐是合理的组合。");
      }

      const matchedTags = meal.tags.filter((tag) =>
        Array.from(preferenceSet).some(
          (preference) => normalize(tag).includes(normalize(preference)) || normalize(preference).includes(normalize(tag)),
        ),
      );
      if (matchedTags.length) {
        score += Math.min(9, matchedTags.length * 3);
        fitLabels.push(`符合${matchedTags.slice(0, 2).join("、")}偏好`);
      }

      if (input.craving && includesAny(normalize(`${meal.name}${meal.tags.join("")}`), [input.craving])) {
        score += 6;
        reasons.push(`名字或风味中出现“${input.craving}”，更接近你此刻想吃的方向。`);
      }

      if (recentMeals.includes(meal.name)) {
        score -= 11;
      }

      if (input.appetite >= 4) {
        score += Math.min(7, meal.nutrition.calories / 90);
      } else if (input.appetite <= 2 && meal.nutrition.calories < 480) {
        score += 4;
      }

      if (input.context === "outside" && meal.context === "outside") {
        score += 7;
      }

      const memorySignal = memorySignalForMeal(meal, memories);
      score += memorySignal.adjustment;
      if (memorySignal.matched.length) {
        fitLabels.unshift("长期记忆参与判断");
        const memoryReason = describeMemoryInfluence(meal, memories);
        if (memoryReason) reasons.unshift(memoryReason);
      }

      if (!reasons.length) {
        reasons.push("食材、时间与目标之间没有明显冲突，是一份容易执行的完整餐食。");
      }

      return {
        meal,
        score: Math.min(98, Math.max(51, Math.round(score))),
        reasons: reasons.slice(0, 3),
        fitLabels: Array.from(new Set(fitLabels)).slice(0, 3),
      };
    })
    .sort((a, b) => b.score - a.score);
}

export function recommendMeal(
  input: DecisionInput,
  settings: UserSettings,
  recentMeals: string[] = [],
  memories: MemoryEntry[] = [],
): Recommendation | null {
  const ranked = rankMeals(input, settings, recentMeals, memories);
  if (!ranked.length) return null;

  return {
    meal: ranked[0].meal,
    score: ranked[0].score,
    reasons: ranked[0].reasons,
    fitLabels: ranked[0].fitLabels,
    alternatives: ranked.slice(1, 3).map((item) => item.meal),
    source: "local",
  };
}

export function explainEmptyRecommendation(taboos: string[]): string {
  return taboos.length
    ? `当前忌口（${taboos.join("、")}）排除了全部候选餐。可以放宽一项条件，或先添加一份自己的餐食记录。`
    : "当前条件下没有找到合适餐食，请调整时间、预算或用餐场景。";
}
