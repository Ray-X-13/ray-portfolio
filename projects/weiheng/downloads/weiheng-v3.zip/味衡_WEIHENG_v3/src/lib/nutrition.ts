import type { MealRecord, Nutrition } from "../types";
import { dateDaysAgo, localDate } from "./storage";

export const emptyNutrition = (): Nutrition => ({
  calories: 0,
  protein: 0,
  carbs: 0,
  fat: 0,
  fiber: 0,
});

export function formatEstimatedRange(value: number, ratio = 0.12): string {
  if (!value) return "—";
  return `${Math.round(value * (1 - ratio) / 5) * 5}–${Math.round(value * (1 + ratio) / 5) * 5}`;
}

export function sumNutrition(records: MealRecord[]): Nutrition {
  return records.reduce(
    (total, record) => ({
      calories: total.calories + record.nutrition.calories,
      protein: total.protein + record.nutrition.protein,
      carbs: total.carbs + record.nutrition.carbs,
      fat: total.fat + record.nutrition.fat,
      fiber: total.fiber + record.nutrition.fiber,
    }),
    emptyNutrition(),
  );
}

export function getLastSevenDays(records: MealRecord[]) {
  return Array.from({ length: 7 }, (_, index) => {
    const daysAgo = 6 - index;
    const date = dateDaysAgo(daysAgo);
    const dayRecords = records.filter((record) => record.date === date);
    const nutrition = sumNutrition(dayRecords);
    return {
      date,
      label: new Intl.DateTimeFormat("zh-CN", { weekday: "short" }).format(
        new Date(`${date}T12:00:00`),
      ),
      records: dayRecords,
      nutrition,
    };
  });
}

export function getTodayRecords(records: MealRecord[]) {
  return records.filter((record) => record.date === localDate());
}

export function getMacroTotals(records: MealRecord[]) {
  const total = sumNutrition(records);
  const macroEnergy = total.protein * 4 + total.carbs * 4 + total.fat * 9;
  if (!macroEnergy) {
    return { protein: 0, carbs: 0, fat: 0 };
  }
  return {
    protein: Math.round(((total.protein * 4) / macroEnergy) * 100),
    carbs: Math.round(((total.carbs * 4) / macroEnergy) * 100),
    fat: Math.round(((total.fat * 9) / macroEnergy) * 100),
  };
}
