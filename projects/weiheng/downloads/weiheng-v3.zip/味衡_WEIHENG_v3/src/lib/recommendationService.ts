import type { DecisionInput, MemoryEntry, Recommendation, UserSettings } from "../types";
import { recommendMeal } from "./recommendation";
import { meals } from "../data/meals";

type ServiceResult = {
  recommendation: Recommendation | null;
  usedRemoteModel: boolean;
  warning?: string;
};

function isRecommendationPayload(value: unknown): value is Recommendation {
  if (!value || typeof value !== "object") return false;
  const candidate = value as Partial<Recommendation>;
  return (
    typeof candidate.score === "number" &&
    Array.isArray(candidate.reasons) &&
    Array.isArray(candidate.fitLabels) &&
    Boolean(candidate.meal) &&
    typeof candidate.meal?.name === "string" &&
    typeof candidate.meal?.minutes === "number" &&
    Boolean(candidate.meal?.nutrition)
  );
}

export async function generateRecommendation(
  input: DecisionInput,
  settings: UserSettings,
  recentMeals: string[],
  memories: MemoryEntry[] = [],
): Promise<ServiceResult> {
  const endpoint = import.meta.env.VITE_AI_ENDPOINT?.trim();
  const localRecommendation = recommendMeal(input, settings, recentMeals, memories);

  if (!endpoint) {
    return { recommendation: localRecommendation, usedRemoteModel: false };
  }

  try {
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 12_000);
    const response = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        input,
        settings,
        recentMeals,
        memories: memories.filter((memory) => memory.status === "confirmed"),
        catalog: meals,
        responseLanguage: "zh-CN",
      }),
      signal: controller.signal,
    });
    window.clearTimeout(timeout);
    if (!response.ok) throw new Error(`AI endpoint returned ${response.status}`);
    const payload: unknown = await response.json();
    if (!isRecommendationPayload(payload)) throw new Error("AI response schema is invalid");
    return {
      recommendation: {
        ...payload,
        reasons: payload.reasons.map(String),
        fitLabels: payload.fitLabels.map(String),
        alternatives: Array.isArray(payload.alternatives) ? payload.alternatives : [],
        source: "api",
      },
      usedRemoteModel: true,
    };
  } catch {
    return {
      recommendation: localRecommendation,
      usedRemoteModel: false,
      warning: "智能服务暂时不可用，已切换到本地规则推荐。",
    };
  }
}
