import { describe, expect, it } from "vitest";
import { defaultSettings } from "../data/meals";
import { isMealSafe, rankMeals, recommendMeal } from "./recommendation";
import type { DecisionInput } from "../types";

const baseInput: DecisionInput = {
  craving: "热食",
  ingredients: ["鸡蛋", "番茄"],
  budget: 30,
  minutes: 25,
  goal: "balanced",
  appetite: 3,
  context: "home",
};

describe("recommendation engine", () => {
  it("returns a transparent local recommendation with reasons", () => {
    const result = recommendMeal(baseInput, defaultSettings, []);
    expect(result).not.toBeNull();
    expect(result?.source).toBe("local");
    expect(result?.reasons.length).toBeGreaterThan(0);
    expect(result?.meal.name).toBeTruthy();
  });

  it("uses saved budget and time as meaningful constraints", () => {
    const ranked = rankMeals(
      { ...baseInput, budget: 10, minutes: 10, context: "outside" },
      defaultSettings,
    );
    expect(ranked.every((item) => item.meal.cost > 10 || item.meal.context === "outside")).toBe(true);
  });

  it("excludes a taboo ingredient from all results", () => {
    const safeMeals = rankMeals(baseInput, {
      ...defaultSettings,
      taboos: ["鸡蛋"],
    });
    expect(safeMeals.length).toBeGreaterThan(0);
    expect(safeMeals.every((item) => !item.meal.ingredients.includes("鸡蛋"))).toBe(true);
  });

  it("recognizes allergen metadata, not only ingredient lists", () => {
    const eggMeal = rankMeals(baseInput, defaultSettings).find((item) =>
      item.meal.allergens.includes("鸡蛋"),
    );
    expect(eggMeal).toBeDefined();
    if (eggMeal) expect(isMealSafe(eggMeal.meal, ["鸡蛋"])).toBe(false);
  });

  it("prioritizes useful ingredients when available", () => {
    const result = recommendMeal(baseInput, defaultSettings, []);
    const coverage = result?.meal.ingredients.filter((item) =>
      ["鸡蛋", "番茄", "青菜", "米饭"].includes(item),
    ).length;
    expect(coverage).toBeGreaterThanOrEqual(2);
  });

  it("changes the decision when the meal situation changes", () => {
    const homeResult = recommendMeal(baseInput, defaultSettings, []);
    const outsideResult = recommendMeal(
      {
        ...baseInput,
        craving: "省时",
        ingredients: [],
        budget: 30,
        minutes: 10,
        context: "outside",
      },
      { ...defaultSettings, commonIngredients: [] },
    );

    expect(homeResult).not.toBeNull();
    expect(outsideResult).not.toBeNull();
    expect(outsideResult?.meal.id).not.toBe(homeResult?.meal.id);
    expect(outsideResult?.meal.context).not.toBe("home");
  });
});
