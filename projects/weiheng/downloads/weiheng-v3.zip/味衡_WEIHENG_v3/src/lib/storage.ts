import type { MealRecord, MemoryEntry, UserSettings } from "../types";
import { defaultSettings } from "../data/meals";

const SETTINGS_KEY = "weiheng-settings-v2";
const RECORDS_KEY = "weiheng-records-v2";
const MEMORY_KEY = "weiheng-memory-v2";

const pad = (value: number) => String(value).padStart(2, "0");

export function localDate(date = new Date()): string {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

export function dateDaysAgo(days: number): string {
  const date = new Date();
  date.setDate(date.getDate() - days);
  return localDate(date);
}

const makeDemoRecord = (
  id: string,
  daysAgo: number,
  mealType: MealRecord["mealType"],
  title: string,
  ingredients: string[],
  nutrition: MealRecord["nutrition"],
  note = "",
): MealRecord => ({
  id,
  date: dateDaysAgo(daysAgo),
  mealType,
  title,
  ingredients,
  nutrition,
  note,
  createdAt: new Date().toISOString(),
  origin: "demo",
});

export const demoRecords: MealRecord[] = [
  makeDemoRecord(
    "demo-1",
    0,
    "早餐",
    "无糖酸奶燕麦杯",
    ["酸奶", "燕麦", "蓝莓"],
    { calories: 318, protein: 16, carbs: 41, fat: 10, fiber: 5.4 },
    "十分钟内完成。",
  ),
  makeDemoRecord(
    "demo-2",
    0,
    "午餐",
    "番茄滑蛋青菜饭",
    ["鸡蛋", "番茄", "青菜", "米饭"],
    { calories: 486, protein: 22, carbs: 58, fat: 17, fiber: 5.2 },
    "由味衡建议。",
  ),
  makeDemoRecord(
    "demo-3",
    1,
    "晚餐",
    "香煎豆腐菌菇饭",
    ["豆腐", "菌菇", "青菜", "米饭"],
    { calories: 432, protein: 20, carbs: 52, fat: 15, fiber: 7.1 },
  ),
  makeDemoRecord(
    "demo-4",
    1,
    "午餐",
    "鸡胸藜麦能量碗",
    ["鸡胸肉", "藜麦", "西兰花"],
    { calories: 522, protein: 38, carbs: 48, fat: 18, fiber: 8.3 },
  ),
  makeDemoRecord(
    "demo-5",
    2,
    "晚餐",
    "番茄牛肉荞麦面",
    ["牛肉", "番茄", "荞麦面", "青菜"],
    { calories: 596, protein: 31, carbs: 68, fat: 21, fiber: 7.4 },
  ),
  makeDemoRecord(
    "demo-6",
    3,
    "午餐",
    "虾仁西兰花蒸蛋",
    ["虾仁", "鸡蛋", "西兰花", "米饭"],
    { calories: 418, protein: 30, carbs: 42, fat: 14, fiber: 3.8 },
  ),
  makeDemoRecord(
    "demo-7",
    4,
    "早餐",
    "南瓜小米粥配水煮蛋",
    ["南瓜", "小米", "鸡蛋", "青菜"],
    { calories: 376, protein: 16, carbs: 57, fat: 10, fiber: 6.6 },
  ),
];

function isSettings(value: unknown): value is UserSettings {
  if (!value || typeof value !== "object") return false;
  const settings = value as Partial<UserSettings>;
  return (
    typeof settings.displayName === "string" &&
    Array.isArray(settings.preferences) &&
    Array.isArray(settings.taboos) &&
    Array.isArray(settings.commonIngredients) &&
    typeof settings.budget === "number" &&
    typeof settings.defaultMinutes === "number" &&
    typeof settings.goal === "string"
  );
}

export function loadSettings(): UserSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return defaultSettings;
    const parsed: unknown = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object") return defaultSettings;
    const merged = { ...defaultSettings, ...parsed };
    return isSettings(merged) ? merged : defaultSettings;
  } catch {
    return defaultSettings;
  }
}

export function saveSettings(settings: UserSettings): boolean {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    return true;
  } catch {
    return false;
  }
}

export function loadRecords(): MealRecord[] {
  try {
    const raw = localStorage.getItem(RECORDS_KEY);
    if (!raw) return demoRecords;
    const parsed: unknown = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as MealRecord[]) : demoRecords;
  } catch {
    return demoRecords;
  }
}

export function saveRecords(records: MealRecord[]): boolean {
  try {
    localStorage.setItem(RECORDS_KEY, JSON.stringify(records));
    return true;
  } catch {
    return false;
  }
}

export function loadMemories(): MemoryEntry[] {
  try {
    const raw = localStorage.getItem(MEMORY_KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as MemoryEntry[]) : [];
  } catch {
    return [];
  }
}

export function saveMemories(memories: MemoryEntry[]): boolean {
  try {
    localStorage.setItem(MEMORY_KEY, JSON.stringify(memories));
    return true;
  } catch {
    return false;
  }
}

export function resetAllData(): void {
  localStorage.removeItem(SETTINGS_KEY);
  localStorage.removeItem(RECORDS_KEY);
  localStorage.removeItem(MEMORY_KEY);
}
