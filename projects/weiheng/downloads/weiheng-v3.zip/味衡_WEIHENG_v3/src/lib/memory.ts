import type { Meal, MealRecord, MemoryEntry } from "../types";

export const memoryTags = ["家常", "清淡", "热食", "高蛋白", "少油", "有汤", "饱腹", "省时"];

const normalize = (value: string) => value.trim().toLowerCase().replace(/\s+/g, "");

function relevantTags(record: MealRecord): string[] {
  return Array.from(new Set(record.sourceTags ?? []))
    .filter((tag) => memoryTags.some((candidate) => normalize(tag).includes(normalize(candidate))))
    .slice(0, 2);
}

export function deriveMemories(
  records: MealRecord[],
  previous: MemoryEntry[] = [],
): MemoryEntry[] {
  const previousById = new Map(previous.map((entry) => [entry.id, entry]));
  const groups = new Map<string, { kind: MemoryEntry["kind"]; tag: string; recordIds: string[] }>();

  records.forEach((record) => {
    if (record.origin !== "recommendation" || !record.satisfaction) return;
    if (record.satisfaction === "okay") return;
    const kind = record.satisfaction === "good" ? "preference" : "avoidance";
    relevantTags(record).forEach((tag) => {
      const id = `memory-${kind}-${normalize(tag)}`;
      const group = groups.get(id) ?? { kind, tag, recordIds: [] };
      if (!group.recordIds.includes(record.id)) group.recordIds.push(record.id);
      groups.set(id, group);
    });
  });

  const next = Array.from(groups.entries()).map(([id, group]) => {
    const old = previousById.get(id);
    const count = group.recordIds.length;
    const statement =
      group.kind === "preference"
        ? `你更容易接受“${group.tag}”型餐食`
        : `“${group.tag}”型餐食可能不太适合你`;
    const detail =
      group.kind === "preference"
        ? `来自 ${count} 次餐后正向反馈。味衡会在后续生成中适度提高相近餐食的优先级。`
        : `来自 ${count} 次餐后负向反馈。味衡会在后续生成中降低相近餐食的优先级。`;
    return {
      id,
      kind: group.kind,
      tag: group.tag,
      statement,
      detail,
      evidenceRecordIds: group.recordIds,
      status: old?.status ?? "candidate",
      updatedAt: new Date().toISOString(),
    } satisfies MemoryEntry;
  });

  const preserved = previous.filter(
    (entry) => !next.some((candidate) => candidate.id === entry.id) && entry.evidenceRecordIds.some(
      (recordId) => records.some((record) => record.id === recordId),
    ),
  );

  return [...next, ...preserved];
}

export function memorySignalForMeal(meal: Meal, memories: MemoryEntry[]) {
  const confirmed = memories.filter((memory) => memory.status === "confirmed");
  const matched = confirmed.filter((memory) =>
    meal.tags.some(
      (tag) => normalize(tag).includes(normalize(memory.tag)) || normalize(memory.tag).includes(normalize(tag)),
    ),
  );
  return {
    adjustment: matched.reduce(
      (total, memory) => total + (memory.kind === "preference" ? 6 : -7),
      0,
    ),
    matched,
  };
}

export function describeMemoryInfluence(meal: Meal, memories: MemoryEntry[]): string | null {
  const signal = memorySignalForMeal(meal, memories);
  if (!signal.matched.length) return null;
  const preference = signal.matched.find((memory) => memory.kind === "preference");
  const avoidance = signal.matched.find((memory) => memory.kind === "avoidance");
  if (preference) return `长期记忆显示你更容易接受“${preference.tag}”型餐食，因此它得到优先考虑。`;
  if (avoidance) return `长期记忆提示“${avoidance.tag}”型餐食可能不合适，因此它被降权。`;
  return null;
}
