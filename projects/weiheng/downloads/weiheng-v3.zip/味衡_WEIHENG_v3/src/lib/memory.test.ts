import { describe, expect, it } from "vitest";
import { meals } from "../data/meals";
import type { MealRecord, MemoryEntry } from "../types";
import { deriveMemories, memorySignalForMeal } from "./memory";

const record: MealRecord = {
  id: "recommendation-1",
  date: "2026-11-22",
  mealType: "午餐",
  title: "番茄滑蛋青菜饭",
  ingredients: ["鸡蛋", "番茄", "青菜", "米饭"],
  note: "",
  nutrition: { calories: 486, protein: 22, carbs: 58, fat: 17, fiber: 5.2 },
  satisfaction: "good",
  sourceTags: ["热食", "家常"],
  createdAt: "2026-11-22T10:00:00.000Z",
  origin: "recommendation",
};

describe("long-term memory", () => {
  it("turns a recommendation feedback into reviewable candidates", () => {
    const memories = deriveMemories([record]);
    expect(memories.length).toBe(2);
    expect(memories.every((memory) => memory.status === "candidate")).toBe(true);
    expect(memories.map((memory) => memory.tag)).toContain("热食");
  });

  it("does not infer memory from an unrated manual record", () => {
    const memories = deriveMemories([
      { ...record, id: "manual-1", origin: "manual", satisfaction: undefined },
    ]);
    expect(memories).toEqual([]);
  });

  it("only confirmed memory changes meal scoring", () => {
    const candidate = deriveMemories([record]).find((memory) => memory.tag === "热食")!;
    const meal = meals.find((item) => item.tags.includes("热食"))!;
    expect(memorySignalForMeal(meal, [candidate]).adjustment).toBe(0);

    const confirmed: MemoryEntry = { ...candidate, status: "confirmed" };
    expect(memorySignalForMeal(meal, [confirmed]).adjustment).toBe(6);
  });

  it("preserves an explicit dismissal instead of recreating the same candidate", () => {
    const initial = deriveMemories([record]);
    const dismissed = initial.map((memory) => ({ ...memory, status: "dismissed" as const }));
    const rebuilt = deriveMemories([record], dismissed);
    expect(rebuilt.every((memory) => memory.status === "dismissed")).toBe(true);
  });
});
