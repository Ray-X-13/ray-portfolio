import { useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  ChevronRight,
  Clock3,
  CookingPot,
  LoaderCircle,
  MapPin,
  Plus,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  Utensils,
  Wallet,
} from "lucide-react";
import { goalLabels, ingredientOptions } from "../data/meals";
import { explainEmptyRecommendation, isMealSafe, rankMeals } from "../lib/recommendation";
import type { DecisionInput, Goal, Meal, MemoryEntry, Recommendation, UserSettings } from "../types";
import { PageHeader } from "../components/PageHeader";

type DecisionPageProps = {
  settings: UserSettings;
  memories: MemoryEntry[];
  recentMeals: string[];
  onRecommend: (input: DecisionInput) => Promise<{
    recommendation: Recommendation | null;
    warning?: string;
  }>;
  onAccept: (meal: Meal) => void;
  onOpenSettings: () => void;
};

const goals: Goal[] = ["balanced", "highProtein", "fatLoss", "energy"];
const estimatedRange = (value: number, ratio = 0.15) =>
  `${Math.round(value * (1 - ratio))}–${Math.round(value * (1 + ratio))}`;

function makeInitialInput(settings: UserSettings): DecisionInput {
  return {
    craving: "",
    ingredients: settings.commonIngredients.slice(0, 6),
    budget: settings.budget,
    minutes: settings.defaultMinutes,
    goal: settings.goal,
    appetite: 3,
    context: "home",
  };
}

export function DecisionPage({
  settings,
  memories,
  recentMeals,
  onRecommend,
  onAccept,
  onOpenSettings,
}: DecisionPageProps) {
  const hasRemoteEndpoint = Boolean(import.meta.env.VITE_AI_ENDPOINT?.trim());
  const [input, setInput] = useState<DecisionInput>(() => makeInitialInput(settings));
  const [ingredientInput, setIngredientInput] = useState("");
  const [result, setResult] = useState<Recommendation | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [hasGenerated, setHasGenerated] = useState(false);
  const resultRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!result || loading || window.innerWidth > 980) return;
    window.setTimeout(() => {
      resultRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 120);
  }, [result, loading]);

  const updateInput = <K extends keyof DecisionInput>(key: K, value: DecisionInput[K]) => {
    setInput((previous) => ({ ...previous, [key]: value }));
  };

  const toggleIngredient = (ingredient: string) => {
    updateInput(
      "ingredients",
      input.ingredients.includes(ingredient)
        ? input.ingredients.filter((item) => item !== ingredient)
        : [...input.ingredients, ingredient],
    );
  };

  const addIngredient = () => {
    const value = ingredientInput.trim();
    if (!value || input.ingredients.includes(value)) {
      setIngredientInput("");
      return;
    }
    updateInput("ingredients", [...input.ingredients, value]);
    setIngredientInput("");
  };

  const generate = async () => {
    setLoading(true);
    setError("");
    const startedAt = Date.now();
    const response = await onRecommend(input);
    const remaining = Math.max(0, 720 - (Date.now() - startedAt));
    await new Promise((resolve) => window.setTimeout(resolve, remaining));
    setResult(response.recommendation);
    setHasGenerated(true);
    setError(
      response.recommendation
        ? response.warning ?? ""
        : explainEmptyRecommendation(settings.taboos),
    );
    setLoading(false);
  };

  const selectAlternative = (meal: Meal) => {
    if (!result) return;
    const ranked = rankMeals(input, settings, recentMeals, memories);
    const selected = ranked.find((item) => item.meal.id === meal.id);
    if (!selected) return;
    const alternatives = ranked
      .filter((item) => item.meal.id !== meal.id)
      .slice(0, 2)
      .map((item) => item.meal);
    setResult({
      ...result,
      meal: selected.meal,
      score: selected.score,
      reasons: selected.reasons,
      fitLabels: selected.fitLabels,
      alternatives,
    });
  };

  const alternativeDifference = (meal: Meal) => {
    if (!result) return "";
    const differences: string[] = [];
    if (meal.minutes < result.meal.minutes) differences.push(`快 ${result.meal.minutes - meal.minutes} 分钟`);
    if (meal.cost < result.meal.cost) differences.push(`省 ¥${result.meal.cost - meal.cost}`);
    if (meal.nutrition.protein > result.meal.nutrition.protein) differences.push("更多蛋白质");
    if (meal.nutrition.fiber > result.meal.nutrition.fiber) differences.push("更多纤维");
    if (meal.nutrition.calories < result.meal.nutrition.calories) differences.push("更轻一些");
    return differences.slice(0, 2).join(" · ") || "同样符合当前条件";
  };

  return (
    <div className="page decision-page">
      <PageHeader
        index="02"
        eyebrow="此刻的条件与取舍"
        title="现在，吃什么？"
        description="先看此刻真正拥有的条件，再决定一份能完成的餐。"
        action={
          <div className="decision-mode">
            <i aria-hidden="true" />
            <span>
              <b>{hasRemoteEndpoint ? "智能模型 + 规则护栏" : "本地规则引擎"}</b>
              <small>{hasRemoteEndpoint ? "服务端安全接入" : "无需 API Key"}</small>
            </span>
          </div>
        }
      />

      <div className="decision-grid">
        <section className="decision-form panel" aria-label="这一餐的条件">
          <div className="form-section-intro">
            <span className="micro-label">01 / 此刻条件</span>
            <h2>告诉我此刻的条件</h2>
            <p>不必精确。你给得越具体，答案越容易执行。</p>
          </div>

          <label className="field-block craving-field">
            <span className="field-label">
              此刻想吃什么
              <small>可选</small>
            </span>
            <textarea
              value={input.craving}
              onChange={(event) => updateInput("craving", event.target.value)}
              placeholder="例如：想吃热的、有点汤，但不要太重口"
              rows={3}
            />
            <span className="field-hint">写下风味、温度或具体食物都可以。</span>
          </label>

          <div className="field-block goal-field">
            <span className="field-label">用餐场景</span>
            <div className="segmented-control">
              <button
                className={input.context === "home" ? "is-active" : ""}
                type="button"
                onClick={() => updateInput("context", "home")}
              >
                <CookingPot size={17} aria-hidden="true" />
                在家做
              </button>
              <button
                className={input.context === "outside" ? "is-active" : ""}
                type="button"
                onClick={() => updateInput("context", "outside")}
              >
                <MapPin size={17} aria-hidden="true" />
                外食 / 便利店
              </button>
            </div>
          </div>

          <div className="field-block context-field">
            <span className="field-label">
              手边已有的食材
              <small>{input.ingredients.length} 项已选</small>
            </span>
            <div className="choice-cloud">
              {ingredientOptions.map((ingredient) => (
                <button
                  key={ingredient}
                  className={input.ingredients.includes(ingredient) ? "is-selected" : ""}
                  type="button"
                  onClick={() => toggleIngredient(ingredient)}
                  aria-pressed={input.ingredients.includes(ingredient)}
                >
                  {input.ingredients.includes(ingredient) ? (
                    <Check size={13} aria-hidden="true" />
                  ) : (
                    <Plus size={13} aria-hidden="true" />
                  )}
                  {ingredient}
                </button>
              ))}
            </div>
            <div className="inline-add">
              <input
                value={ingredientInput}
                onChange={(event) => setIngredientInput(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter") {
                    event.preventDefault();
                    addIngredient();
                  }
                }}
                placeholder="补充其他食材"
                aria-label="补充其他食材"
              />
              <button type="button" onClick={addIngredient}>
                添加
              </button>
            </div>
            {input.ingredients
              .filter((item) => !ingredientOptions.includes(item))
              .map((ingredient) => (
                <button
                  type="button"
                  className="custom-ingredient"
                  key={ingredient}
                  onClick={() => toggleIngredient(ingredient)}
                >
                  {ingredient} <span aria-hidden="true">×</span>
                </button>
              ))}
          </div>

          <div className="field-pair">
            <label className="range-field">
              <span className="field-label">
                <Clock3 size={15} aria-hidden="true" />
                可用时间
                <b>{input.minutes} 分钟</b>
              </span>
              <input
                type="range"
                min="10"
                max="45"
                step="5"
                value={input.minutes}
                onChange={(event) => updateInput("minutes", Number(event.target.value))}
              />
              <span className="range-ends">
                <small>10</small>
                <small>45 分钟</small>
              </span>
            </label>
            <label className="range-field">
              <span className="field-label">
                <Wallet size={15} aria-hidden="true" />
                这餐预算
                <b>¥{input.budget}</b>
              </span>
              <input
                type="range"
                min="10"
                max="60"
                step="1"
                value={input.budget}
                onChange={(event) => updateInput("budget", Number(event.target.value))}
              />
              <span className="range-ends">
                <small>¥10</small>
                <small>¥60</small>
              </span>
            </label>
          </div>

          <div className="field-block ingredient-field">
            <span className="field-label">饮食目标</span>
            <div className="goal-choice-grid">
              {goals.map((goal) => (
                <button
                  key={goal}
                  type="button"
                  className={input.goal === goal ? "is-selected" : ""}
                  onClick={() => updateInput("goal", goal)}
                >
                  <span>{goalLabels[goal]}</span>
                  <i aria-hidden="true" />
                </button>
              ))}
            </div>
          </div>

          <div className="field-block appetite-field">
            <span className="field-label">
              此刻饥饿感
              <small>1 = 不太饿 · 5 = 很饿</small>
            </span>
            <div className="appetite-scale">
              {[1, 2, 3, 4, 5].map((level) => (
                <button
                  key={level}
                  type="button"
                  className={input.appetite === level ? "is-selected" : ""}
                  onClick={() => updateInput("appetite", level as DecisionInput["appetite"])}
                  aria-label={`饥饿感 ${level}`}
                >
                  <span style={{ height: `${22 + level * 9}%` }} />
                  <small>{level}</small>
                </button>
              ))}
            </div>
          </div>

          <div className="saved-rule-note">
            <ShieldCheck size={17} aria-hidden="true" />
            <p>
              已自动避开：<strong>{settings.taboos.length ? settings.taboos.join("、") : "暂无忌口"}</strong>
              <button type="button" onClick={onOpenSettings}>修改设置</button>
            </p>
          </div>

          <div className="decision-context-note">
            <span>本次判断会参考</span>
            <strong>{memories.filter((memory) => memory.status === "confirmed").length} 条长期记忆</strong>
            <span>+ 当前条件</span>
          </div>

          <button className="button button-primary generate-button" type="button" onClick={generate} disabled={loading}>
            {loading ? (
              <>
                <LoaderCircle className="spin" size={19} aria-hidden="true" />
                正在组合这一餐
              </>
            ) : (
              <>
                <Sparkles size={19} aria-hidden="true" />
                {hasGenerated ? "重新生成一餐" : "生成一餐建议"}
                <ArrowRight size={18} aria-hidden="true" />
              </>
            )}
          </button>
          {error ? <p className="form-error" role="alert">{error}</p> : null}
        </section>

        <section
          ref={resultRef}
          className={`decision-result${result ? " has-result" : ""}`}
          aria-live="polite"
        >
          {loading ? (
            <div className="result-loading">
              <div className="loading-plate" aria-hidden="true">
                <span />
                <i />
              </div>
              <span className="micro-label">BUILDING A MEAL</span>
              <h2>正在把条件变成一餐</h2>
              <p>核对食材、预算、时间和已保存的偏好…</p>
              <div className="loading-lines" aria-hidden="true">
                <span />
                <span />
                <span />
              </div>
            </div>
          ) : result ? (
            <article className="meal-result-card">
              <div className="result-topline">
                <span className="result-kind">
                  <Utensils size={15} aria-hidden="true" />
                  你的这一餐
                </span>
                <span className="source-badge">
                  {result.source === "api" ? "智能模型" : "本地规则推荐"}
                </span>
              </div>

              <div className="result-hero">
                <div className="result-copy">
                  <span className="micro-label">MEAL / {result.meal.id.slice(0, 8).toUpperCase()}</span>
                  <h2>{result.meal.name}</h2>
                  <p>{result.meal.subtitle}</p>
                  <div className="result-facts">
                    <span><Clock3 size={15} />{result.meal.minutes} 分钟</span>
                    <span><Wallet size={15} />约 ¥{result.meal.cost}</span>
                    <span><CookingPot size={15} />{result.meal.steps.length} 步</span>
                  </div>
                </div>
                <div className="score-orbit" aria-label={`匹配度 ${result.score} 分`}>
                  <span style={{ "--score": `${result.score * 3.6}deg` } as React.CSSProperties}>
                    <b>{result.score}</b>
                    <small>匹配度</small>
                  </span>
                  <i aria-hidden="true" />
                </div>
              </div>

              <div className="fit-strip">
                {result.fitLabels.map((label) => (
                  <span key={label}>
                    <Check size={13} aria-hidden="true" />
                    {label}
                  </span>
                ))}
              </div>

              <div className="decision-trace">
                <div>
                  <span>01</span>
                  <p>读取偏好与长期记忆</p>
                  <b>{memories.filter((memory) => memory.status === "confirmed").length} 条已确认</b>
                </div>
                <i aria-hidden="true" />
                <div>
                  <span>02</span>
                  <p>排除忌口并比较条件</p>
                  <b>{settings.taboos.length} 项安全边界</b>
                </div>
                <i aria-hidden="true" />
                <div>
                  <span>03</span>
                  <p>给出主建议</p>
                  <b>{result.source === "local" ? "可解释规则" : "模型 + 规则校验"}</b>
                </div>
              </div>

              <div className="result-sections">
                <section className="reason-box">
                  <span className="micro-label">推荐依据</span>
                  <h3>为什么是它</h3>
                  <div className="reason-list">
                    {result.reasons.map((reason, index) => (
                      <p key={reason}>
                        <span>0{index + 1}</span>
                        {reason}
                      </p>
                    ))}
                  </div>
                </section>

                <section className="nutrition-box">
                  <span className="micro-label">营养轮廓 · 估算</span>
                  <h3>一餐营养估算</h3>
                  <div className="calorie-number">
                    <small>约</small>
                    <strong>{estimatedRange(result.meal.nutrition.calories)}</strong>
                    <span>kcal</span>
                  </div>
                  <div className="macro-grid">
                    <span><b>{estimatedRange(result.meal.nutrition.protein)} g</b>蛋白质</span>
                    <span><b>{estimatedRange(result.meal.nutrition.carbs)} g</b>碳水</span>
                    <span><b>{estimatedRange(result.meal.nutrition.fat)} g</b>脂肪</span>
                    <span><b>{estimatedRange(result.meal.nutrition.fiber, 0.2)} g</b>膳食纤维</span>
                  </div>
                  <small className="estimate-note">
                    以常见家常份量为基础估算，未考虑品牌、称重与烹饪损耗。
                  </small>
                </section>
              </div>

              <section className="ingredient-step-box">
                <div className="ingredient-column">
                  <span className="micro-label">食材</span>
                  <h3>你需要</h3>
                  <ul>
                    {result.meal.ingredients.map((ingredient) => (
                      <li key={ingredient}>
                        <span aria-hidden="true" />
                        {ingredient}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="step-column">
                  <span className="micro-label">简单做法</span>
                  <h3>简单做法</h3>
                  <ol>
                    {result.meal.steps.map((step, index) => (
                      <li key={step}>
                        <span>0{index + 1}</span>
                        <p>{step}</p>
                      </li>
                    ))}
                  </ol>
                </div>
              </section>

              {result.alternatives.length ? (
                <section className="alternatives">
                  <div className="alternative-heading">
                    <div>
                      <span className="micro-label">替代选择</span>
                      <h3>还可以替换成</h3>
                    </div>
                    <span>同样符合当前条件</span>
                  </div>
                  <div className="alternative-list">
                    {result.alternatives.map((meal) => (
                      <button key={meal.id} type="button" onClick={() => selectAlternative(meal)}>
                        <div>
                          <strong>{meal.name}</strong>
                          <small>{meal.minutes} 分钟 · 约 ¥{meal.cost} · {alternativeDifference(meal)}</small>
                        </div>
                        <RefreshCw size={15} aria-hidden="true" />
                      </button>
                    ))}
                  </div>
                </section>
              ) : null}

              <div className="result-actions">
                <button className="button button-primary" type="button" onClick={() => onAccept(result.meal)}>
                  <Check size={18} aria-hidden="true" />
                  就吃这一餐
                </button>
                <button className="button button-quiet" type="button" onClick={generate}>
                  <RefreshCw size={17} aria-hidden="true" />
                  换一个
                </button>
              </div>
            </article>
          ) : (
            <div className="result-empty">
              <div className="empty-illustration" aria-hidden="true">
                <span className="empty-ring one" />
                <span className="empty-ring two" />
                <span className="empty-plate">
                  <i />
                  <i />
                  <i />
                </span>
                <span className="empty-label label-a">时间</span>
                <span className="empty-label label-b">预算</span>
                <span className="empty-label label-c">偏好</span>
              </div>
              <span className="micro-label">YOUR NEXT PLATE</span>
              <h2>先给出条件，<br />再得到一张一餐卡。</h2>
              <p>
                味衡不会给你二十个选项。它会根据已保存的设置与这次的条件，
                先给出一个主建议，再提供可替换方案。
              </p>
              <div className="empty-principles">
                <span><Check size={14} /> 尊重现有食材</span>
                <span><Check size={14} /> 避开忌口</span>
                <span><Check size={14} /> 理由可解释</span>
              </div>
              <button className="button button-secondary" type="button" onClick={generate}>
                <Sparkles size={17} aria-hidden="true" />
                用当前条件试试
                <ChevronRight size={17} aria-hidden="true" />
              </button>
            </div>
          )}
        </section>
      </div>

      <button className="back-to-today" type="button" onClick={() => window.history.length > 1 && window.history.back()}>
        <ArrowLeft size={15} aria-hidden="true" />
        返回今日
      </button>
    </div>
  );
}
