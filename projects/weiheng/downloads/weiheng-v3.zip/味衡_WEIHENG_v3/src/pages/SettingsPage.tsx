import { useState } from "react";
import {
  Check,
  Clock3,
  CircleAlert,
  Database,
  Leaf,
  Plus,
  RotateCcw,
  Save,
  ShieldCheck,
  Sparkles,
  Target,
  Wallet,
} from "lucide-react";
import {
  goalLabels,
  ingredientOptions,
  preferenceOptions,
  tabooOptions,
} from "../data/meals";
import type { Goal, UserSettings } from "../types";
import { PageHeader } from "../components/PageHeader";

type SettingsPageProps = {
  settings: UserSettings;
  onSave: (settings: UserSettings) => void;
  onReset: () => void;
};

const goals: Goal[] = ["balanced", "highProtein", "fatLoss", "energy"];

function toggleValue(values: string[], value: string) {
  return values.includes(value) ? values.filter((item) => item !== value) : [...values, value];
}

export function SettingsPage({ settings, onSave, onReset }: SettingsPageProps) {
  const [form, setForm] = useState(settings);
  const [customTaboo, setCustomTaboo] = useState("");
  const [customIngredient, setCustomIngredient] = useState("");
  const [confirmReset, setConfirmReset] = useState(false);

  const addCustom = (kind: "taboo" | "ingredient", value: string) => {
    const clean = value.trim();
    if (!clean) return;
    if (kind === "taboo") {
      setForm((previous) => ({
        ...previous,
        taboos: previous.taboos.includes(clean) ? previous.taboos : [...previous.taboos, clean],
      }));
      setCustomTaboo("");
    } else {
      setForm((previous) => ({
        ...previous,
        commonIngredients: previous.commonIngredients.includes(clean)
          ? previous.commonIngredients
          : [...previous.commonIngredients, clean],
      }));
      setCustomIngredient("");
    }
  };

  return (
    <div className="page settings-page">
      <PageHeader
        index="05"
        eyebrow="你的边界与偏好"
        title="个性设置"
        description="这些设置会直接进入下一次推荐条件，也会在生成餐卡时默认带入。"
        action={
          <span className="local-private">
            <ShieldCheck size={16} aria-hidden="true" />
            仅保存在本机
          </span>
        }
      />

      <div className="settings-layout">
        <div className="settings-main">
          <section className="settings-card panel">
            <div className="settings-card-head">
              <div className="settings-index">01</div>
              <div>
                <span className="micro-label">基本信息</span>
                <h2>怎么称呼你</h2>
              </div>
            </div>
            <div className="settings-card-body">
              <label className="settings-text-field">
                <span>显示名称</span>
                <input
                  value={form.displayName}
                  onChange={(event) => setForm({ ...form, displayName: event.target.value })}
                  maxLength={12}
                  placeholder="例如：小衡"
                />
              </label>
            </div>
          </section>

          <section className="settings-card panel">
            <div className="settings-card-head">
              <div className="settings-index">02</div>
              <div>
                <span className="micro-label">当前目标</span>
                <h2>当前饮食目标</h2>
              </div>
            </div>
            <div className="settings-card-body">
              <p className="settings-helper">只选择一个，帮助系统在冲突条件之间做出优先级判断。</p>
              <div className="settings-goal-grid">
                {goals.map((goal) => (
                  <button
                    type="button"
                    key={goal}
                    className={form.goal === goal ? "is-selected" : ""}
                    onClick={() => setForm({ ...form, goal })}
                  >
                    <span className="goal-icon">
                      {goal === "balanced" ? <Leaf size={19} /> : goal === "highProtein" ? <Sparkles size={19} /> : goal === "fatLoss" ? <Target size={19} /> : <Wallet size={19} />}
                    </span>
                    <div>
                      <strong>{goalLabels[goal]}</strong>
                      <small>
                        {goal === "balanced" && "兼顾主食、蛋白质与蔬菜"}
                        {goal === "highProtein" && "优先增加优质蛋白质来源"}
                        {goal === "fatLoss" && "关注份量与少油组合"}
                        {goal === "energy" && "让一餐更饱腹、更有持续能量"}
                      </small>
                    </div>
                    <i className={form.goal === goal ? "selected-dot" : ""} aria-hidden="true" />
                  </button>
                ))}
              </div>
            </div>
          </section>

          <section className="settings-card panel">
            <div className="settings-card-head">
              <div className="settings-index">03</div>
              <div>
                <span className="micro-label">饮食偏好</span>
                <h2>饮食偏好</h2>
              </div>
            </div>
            <div className="settings-card-body">
              <p className="settings-helper">可多选。推荐会优先寻找与你偏好相符的餐食。</p>
              <div className="settings-chip-cloud">
                {preferenceOptions.map((preference) => (
                  <button
                    type="button"
                    key={preference}
                    className={form.preferences.includes(preference) ? "is-selected" : ""}
                    onClick={() =>
                      setForm({
                        ...form,
                        preferences: toggleValue(form.preferences, preference),
                      })
                    }
                  >
                    {form.preferences.includes(preference) ? <Check size={14} /> : <Plus size={14} />}
                    {preference}
                  </button>
                ))}
                <button
                  type="button"
                  className={form.preferences.includes("素食") ? "is-selected" : ""}
                  onClick={() =>
                    setForm({
                      ...form,
                      preferences: toggleValue(form.preferences, "素食"),
                    })
                  }
                >
                  {form.preferences.includes("素食") ? <Check size={14} /> : <Plus size={14} />}
                  素食
                </button>
              </div>
            </div>
          </section>

          <section className="settings-card panel">
            <div className="settings-card-head">
              <div className="settings-index">04</div>
              <div>
                <span className="micro-label">安全边界</span>
                <h2>忌口与过敏原</h2>
              </div>
            </div>
            <div className="settings-card-body">
              <div className="safety-callout">
                <CircleAlert size={18} aria-hidden="true" />
                <p>
                  标记后，包含相关食材或过敏原的候选餐会从推荐中排除。
                  严重过敏仍需在购买和食用前核对真实食品标签。
                </p>
              </div>
              <div className="settings-chip-cloud is-dangerous">
                {tabooOptions.map((taboo) => (
                  <button
                    type="button"
                    key={taboo}
                    className={form.taboos.includes(taboo) ? "is-selected" : ""}
                    onClick={() =>
                      setForm({ ...form, taboos: toggleValue(form.taboos, taboo) })
                    }
                  >
                    {form.taboos.includes(taboo) ? <Check size={14} /> : <Plus size={14} />}
                    {taboo}
                  </button>
                ))}
                {form.taboos
                  .filter((taboo) => !tabooOptions.includes(taboo))
                  .map((taboo) => (
                    <button
                      type="button"
                      key={taboo}
                      className="is-selected"
                      onClick={() =>
                        setForm({ ...form, taboos: form.taboos.filter((item) => item !== taboo) })
                      }
                    >
                      <Check size={14} />
                      {taboo}
                    </button>
                  ))}
              </div>
              <div className="inline-add settings-inline-add">
                <input
                  value={customTaboo}
                  onChange={(event) => setCustomTaboo(event.target.value)}
                  onKeyDown={(event) => {
                    if (event.key === "Enter") {
                      event.preventDefault();
                      addCustom("taboo", customTaboo);
                    }
                  }}
                  placeholder="添加其他忌口或过敏原"
                  aria-label="添加其他忌口或过敏原"
                />
                <button type="button" onClick={() => addCustom("taboo", customTaboo)}>添加</button>
              </div>
            </div>
          </section>

          <section className="settings-card panel">
            <div className="settings-card-head">
              <div className="settings-index">05</div>
              <div>
                <span className="micro-label">食材、时间与预算</span>
                <h2>常用食材与预算</h2>
              </div>
            </div>
            <div className="settings-card-body">
              <p className="settings-helper">常用食材会在决策表单中默认选中，减少每次重复输入。</p>
              <div className="settings-chip-cloud is-soft">
                {ingredientOptions.map((ingredient) => (
                  <button
                    type="button"
                    key={ingredient}
                    className={form.commonIngredients.includes(ingredient) ? "is-selected" : ""}
                    onClick={() =>
                      setForm({
                        ...form,
                        commonIngredients: toggleValue(form.commonIngredients, ingredient),
                      })
                    }
                  >
                    {form.commonIngredients.includes(ingredient) ? <Check size={14} /> : <Plus size={14} />}
                    {ingredient}
                  </button>
                ))}
                {form.commonIngredients
                  .filter((ingredient) => !ingredientOptions.includes(ingredient))
                  .map((ingredient) => (
                    <button
                      type="button"
                      key={ingredient}
                      className="is-selected"
                      onClick={() =>
                        setForm({
                          ...form,
                          commonIngredients: form.commonIngredients.filter((item) => item !== ingredient),
                        })
                      }
                    >
                      <Check size={14} />
                      {ingredient}
                    </button>
                  ))}
              </div>
              <div className="inline-add settings-inline-add">
                <input
                  value={customIngredient}
                  onChange={(event) => setCustomIngredient(event.target.value)}
                  onKeyDown={(event) => {
                    if (event.key === "Enter") {
                      event.preventDefault();
                      addCustom("ingredient", customIngredient);
                    }
                  }}
                  placeholder="添加常用食材"
                  aria-label="添加常用食材"
                />
                <button type="button" onClick={() => addCustom("ingredient", customIngredient)}>添加</button>
              </div>

              <div className="budget-setting">
                <div>
                  <span>日常单餐预算</span>
                  <strong>¥{form.budget}</strong>
                </div>
                <input
                  type="range"
                  min="10"
                  max="80"
                  step="1"
                  value={form.budget}
                  onChange={(event) => setForm({ ...form, budget: Number(event.target.value) })}
                  aria-label="日常单餐预算"
                />
                <div className="budget-ends"><span>¥10</span><span>¥80</span></div>
              </div>

              <div className="budget-setting time-setting">
                <div>
                  <span><Clock3 size={15} /> 默认可接受准备时间</span>
                  <strong>{form.defaultMinutes} 分钟</strong>
                </div>
                <input
                  type="range"
                  min="10"
                  max="60"
                  step="5"
                  value={form.defaultMinutes}
                  onChange={(event) =>
                    setForm({ ...form, defaultMinutes: Number(event.target.value) })
                  }
                  aria-label="默认可接受准备时间"
                />
                <div className="budget-ends"><span>10 分钟</span><span>60 分钟</span></div>
              </div>
            </div>
          </section>

          <div className="settings-save-bar">
            <div>
              <span>这些设置将用于下一次推荐</span>
              <p>{goalLabels[form.goal]} · ¥{form.budget} 预算 · {form.preferences.length} 项偏好 · {form.taboos.length} 项忌口</p>
            </div>
            <button className="button button-primary" type="button" onClick={() => onSave(form)}>
              <Save size={18} aria-hidden="true" />
              保存设置
            </button>
          </div>
        </div>

        <aside className="settings-side">
          <section className="settings-preview dark-panel">
            <span className="micro-label">推荐会如何使用这些设置</span>
            <Sparkles size={27} strokeWidth={1.4} aria-hidden="true" />
            <h2>你的下一张一餐卡，会先看这些。</h2>
            <div className="settings-signal-list">
              <div><span>目标</span><strong>{goalLabels[form.goal]}</strong></div>
              <div><span>预算</span><strong>单餐不超过 ¥{form.budget}</strong></div>
              <div><span>时间</span><strong>默认接受 {form.defaultMinutes} 分钟</strong></div>
              <div><span>偏好</span><strong>{form.preferences.length ? form.preferences.join("、") : "未设置"}</strong></div>
              <div><span>忌口</span><strong>{form.taboos.length ? form.taboos.join("、") : "无"}</strong></div>
              <div><span>食材</span><strong>{form.commonIngredients.length} 项默认选中</strong></div>
            </div>
            <p>设置变化后，推荐排序、硬性排除项与默认表单都会同步更新。</p>
          </section>

          <section className="privacy-card panel">
            <Database size={21} strokeWidth={1.5} aria-hidden="true" />
            <h3>数据与隐私</h3>
            <p>当前版本的设置和饮食记录保存在此浏览器的 LocalStorage 中，不会上传服务器。</p>
            <div className="privacy-points">
              <span><Check size={14} /> 无账户系统</span>
              <span><Check size={14} /> 无第三方追踪</span>
              <span><Check size={14} /> 清除站点数据即重置</span>
            </div>
          </section>

          <section className="reset-card">
            <h3>重置演示数据</h3>
            <p>清除所有记录和设置，并恢复初始示例。此操作不可撤销。</p>
            {confirmReset ? (
              <div className="reset-actions">
                <button type="button" onClick={() => setConfirmReset(false)}>取消</button>
                <button type="button" onClick={onReset}>
                  <RotateCcw size={14} />
                  确认重置
                </button>
              </div>
            ) : (
              <button type="button" onClick={() => setConfirmReset(true)}>
                <RotateCcw size={15} />
                重置全部数据
              </button>
            )}
          </section>
        </aside>
      </div>
    </div>
  );
}
