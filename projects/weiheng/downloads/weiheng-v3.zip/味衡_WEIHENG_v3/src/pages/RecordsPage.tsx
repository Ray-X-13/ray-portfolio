import { useMemo, useState } from "react";
import {
  CalendarRange,
  CirclePlus,
  Clock3,
  PencilLine,
  Search,
  Sparkles,
  Trash2,
  Utensils,
} from "lucide-react";
import { formatEstimatedRange, getTodayRecords, sumNutrition } from "../lib/nutrition";
import type { MealRecord } from "../types";
import { PageHeader } from "../components/PageHeader";

type RecordsPageProps = {
  records: MealRecord[];
  onAdd: () => void;
  onEdit: (record: MealRecord) => void;
  onDelete: (id: string) => void;
};

type RecordFilter = "all" | "week" | "demo";

const dateTitle = (date: string) => {
  const today = new Date();
  const target = new Date(`${date}T12:00:00`);
  const diff = Math.round((new Date(today.toDateString()).getTime() - new Date(target.toDateString()).getTime()) / 86_400_000);
  if (diff === 0) return "今天";
  if (diff === 1) return "昨天";
  return new Intl.DateTimeFormat("zh-CN", {
    month: "long",
    day: "numeric",
    weekday: "long",
  }).format(target);
};

const shortDate = (date: string) =>
  new Intl.DateTimeFormat("zh-CN", { month: "2-digit", day: "2-digit" }).format(
    new Date(`${date}T12:00:00`),
  );

export function RecordsPage({ records, onAdd, onEdit, onDelete }: RecordsPageProps) {
  const [filter, setFilter] = useState<RecordFilter>("all");
  const [query, setQuery] = useState("");
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const filteredRecords = useMemo(() => {
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 6);
    return records
      .filter((record) => {
        if (filter === "demo" && record.origin !== "demo") return false;
        if (filter === "week" && record.date < sevenDaysAgo.toISOString().slice(0, 10)) return false;
        const searchable = `${record.title}${record.ingredients.join("")}${record.note}`;
        return !query.trim() || searchable.includes(query.trim());
      })
      .sort((a, b) => {
        const dateComparison = b.date.localeCompare(a.date);
        return dateComparison || b.createdAt.localeCompare(a.createdAt);
      });
  }, [filter, query, records]);

  const grouped = useMemo(() => {
    const map = new Map<string, MealRecord[]>();
    filteredRecords.forEach((record) => {
      map.set(record.date, [...(map.get(record.date) ?? []), record]);
    });
    return Array.from(map.entries());
  }, [filteredRecords]);

  const today = getTodayRecords(records);
  const todayNutrition = sumNutrition(today);
  const mostCommonMealType =
    (["早餐", "午餐", "晚餐", "加餐"] as const)
      .map((type) => ({ type, count: records.filter((record) => record.mealType === type).length }))
      .sort((a, b) => b.count - a.count)[0]?.type ?? "暂无";

  return (
    <div className="page records-page">
      <PageHeader
        index="03"
        eyebrow="真实饮食记录"
        title="饮食记录"
        description="只记下足够有用的信息，让真实生活成为下一次建议的依据。"
        action={
          <button className="button button-primary" type="button" onClick={onAdd}>
            <CirclePlus size={18} aria-hidden="true" />
            添加记录
          </button>
        }
      />

      <div className="records-overview">
        <article>
          <span>今日记录</span>
          <strong>{today.length}<small> / 3 餐</small></strong>
        </article>
        <article>
          <span>今日热量估算</span>
          <strong>{formatEstimatedRange(todayNutrition.calories)}<small> kcal 估算</small></strong>
        </article>
        <article>
          <span>今日蛋白质估算</span>
          <strong>{todayNutrition.protein.toFixed(0)}<small> g</small></strong>
        </article>
        <article>
          <span>最常记录</span>
          <strong className="overview-type">{mostCommonMealType}</strong>
        </article>
      </div>

      <div className="records-layout">
        <section className="records-main panel">
          <div className="records-toolbar">
            <div className="filter-tabs" role="tablist" aria-label="记录筛选">
              <button
                type="button"
                className={filter === "all" ? "is-active" : ""}
                onClick={() => setFilter("all")}
              >
                全部
              </button>
              <button
                type="button"
                className={filter === "week" ? "is-active" : ""}
                onClick={() => setFilter("week")}
              >
                近 7 天
              </button>
              <button
                type="button"
                className={filter === "demo" ? "is-active" : ""}
                onClick={() => setFilter("demo")}
              >
                示例
              </button>
            </div>
            <label className="search-field">
              <Search size={17} aria-hidden="true" />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="搜索餐食或食材"
                aria-label="搜索记录"
              />
            </label>
          </div>

          {grouped.length ? (
            <div className="record-groups">
              {grouped.map(([date, dayRecords]) => (
                <section className="record-day" key={date}>
                  <div className="record-day-heading">
                    <h2>{dateTitle(date)}</h2>
                    <span>{shortDate(date)}</span>
                    <i />
                    <small>{formatEstimatedRange(sumNutrition(dayRecords).calories)} kcal 估算</small>
                  </div>
                  <div className="record-list">
                    {dayRecords.map((record) => (
                      <article className="record-row" key={record.id}>
                        <div className="record-type">
                          <span>{record.mealType.slice(0, 1)}</span>
                          <small>{record.mealType}</small>
                        </div>
                        <div className="record-content">
                          <div className="record-title-line">
                            <h3>{record.title}</h3>
                            {record.origin === "demo" ? <span className="demo-tag">示例</span> : null}
                            {record.origin === "recommendation" ? (
                              <span className="recommend-tag">
                                <Sparkles size={11} />
                                味衡建议
                              </span>
                            ) : null}
                          </div>
                          <div className="record-ingredients">
                            {record.ingredients.map((ingredient) => (
                              <span key={ingredient}>{ingredient}</span>
                            ))}
                          </div>
                          {record.note ? <p className="record-note">{record.note}</p> : null}
                        </div>
                        <div className="record-nutrition">
                          <strong>约 {Math.round(record.nutrition.calories / 10) * 10}</strong>
                          <span>kcal 估算</span>
                          <small>蛋白 {record.nutrition.protein}g</small>
                        </div>
                        <div className="record-actions">
                          {confirmDelete === record.id ? (
                            <div className="delete-confirm">
                              <button type="button" onClick={() => setConfirmDelete(null)}>
                                取消
                              </button>
                              <button
                                className="danger"
                                type="button"
                                onClick={() => {
                                  onDelete(record.id);
                                  setConfirmDelete(null);
                                }}
                              >
                                删除
                              </button>
                            </div>
                          ) : (
                            <>
                              <button type="button" onClick={() => onEdit(record)} aria-label={`编辑${record.title}`}>
                                <PencilLine size={16} />
                              </button>
                              <button
                                type="button"
                                onClick={() => setConfirmDelete(record.id)}
                                aria-label={`删除${record.title}`}
                              >
                                <Trash2 size={16} />
                              </button>
                            </>
                          )}
                        </div>
                      </article>
                    ))}
                  </div>
                </section>
              ))}
            </div>
          ) : (
            <div className="records-empty">
              <div className="records-empty-icon">
                <Utensils size={26} strokeWidth={1.4} aria-hidden="true" />
              </div>
              <h2>{records.length ? "没有匹配的记录" : "今天的第一餐，从记录开始。"}</h2>
              <p>
                {records.length
                  ? "换一个关键词或筛选范围试试。"
                  : "不用称重，也不用写得完整。记下吃了什么，就足够形成下一次反馈。"}
              </p>
              <button className="button button-secondary" type="button" onClick={onAdd}>
                <CirclePlus size={17} aria-hidden="true" />
                添加第一条记录
              </button>
            </div>
          )}
        </section>

        <aside className="records-side">
          <article className="record-tip dark-panel">
            <CalendarRange size={22} strokeWidth={1.5} aria-hidden="true" />
            <span className="micro-label">LIGHTWEIGHT BY DESIGN</span>
            <h2>记录是为了下一次更轻松，不是为了给今天打分。</h2>
            <p>你记录的食物组合、份量与感受，会成为之后的推荐依据。营养数字均为估算。</p>
            <div className="tip-stat">
              <strong>{records.length}</strong>
              <span>餐累计记录<br />全部保存在本机</span>
            </div>
          </article>
          <article className="record-guide panel">
            <Clock3 size={20} strokeWidth={1.5} aria-hidden="true" />
            <h3>一条有用的记录</h3>
            <ul>
              <li><span>01</span>真实的餐名与大致食材</li>
              <li><span>02</span>吃完后的满足感或份量感受</li>
              <li><span>03</span>不必追求每一克都准确</li>
            </ul>
          </article>
        </aside>
      </div>
    </div>
  );
}
