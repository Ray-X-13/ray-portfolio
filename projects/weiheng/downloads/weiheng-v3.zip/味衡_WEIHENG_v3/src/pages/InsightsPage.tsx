import {
  ArrowUpRight,
  Brain,
  CalendarCheck2,
  Check,
  Info,
  LockKeyhole,
  Leaf,
  Salad,
  Sparkles,
  TrendingUp,
  X,
} from "lucide-react";
import { PageHeader } from "../components/PageHeader";
import {
  formatEstimatedRange,
  getLastSevenDays,
  getMacroTotals,
  getTodayRecords,
  sumNutrition,
} from "../lib/nutrition";
import type { MealRecord, MemoryEntry, UserSettings } from "../types";
import { goalLabels } from "../data/meals";

type InsightsPageProps = {
  records: MealRecord[];
  settings: UserSettings;
  memories: MemoryEntry[];
  onMemoryStatus: (id: string, status: MemoryEntry["status"]) => void;
  onDecide: () => void;
  onAdd: () => void;
};

export function InsightsPage({
  records,
  settings,
  memories,
  onMemoryStatus,
  onDecide,
  onAdd,
}: InsightsPageProps) {
  const week = getLastSevenDays(records);
  const weekRecords = week.flatMap((day) => day.records);
  const weekNutrition = sumNutrition(weekRecords);
  const macro = getMacroTotals(weekRecords);
  const today = getTodayRecords(records);
  const todayNutrition = sumNutrition(today);
  const maxCalories = Math.max(1, ...week.map((day) => day.nutrition.calories));
  const recordedDays = week.filter((day) => day.records.length > 0).length;
  const mealsWithVegetables = weekRecords.filter((record) =>
    record.ingredients.some((item) => /菜|蔬|番茄|西兰花|南瓜|菌菇/.test(item)),
  ).length;
  const mealsWithProtein = weekRecords.filter((record) =>
    record.ingredients.some((item) => /蛋|肉|豆腐|虾|鱼|奶/.test(item)),
  ).length;
  const repeatedMeals = weekRecords.filter(
    (record, index, all) => all.findIndex((item) => item.title === record.title) !== index,
  ).length;
  const mealTypes = ["早餐", "午餐", "晚餐", "加餐"] as const;
  const typeCounts = mealTypes.map((type) => ({
    type,
    count: weekRecords.filter((record) => record.mealType === type).length,
  }));
  const avgCalories = weekNutrition.calories
    ? Math.round(weekNutrition.calories / Math.max(1, recordedDays))
    : 0;
  const memoryCandidates = memories.filter((memory) => memory.status === "candidate");
  const confirmedMemories = memories.filter((memory) => memory.status === "confirmed");

  return (
    <div className="page insights-page">
      <PageHeader
        index="04"
        eyebrow="趋势与长期记忆"
        title="饮食反馈"
        description="观察节奏和结构，而不是追求一个看似精确的分数。"
        action={
          <div className="period-chip">
            <CalendarCheck2 size={16} aria-hidden="true" />
            最近 7 天
          </div>
        }
      />

      <div className="insight-metrics">
        <article>
          <span>记录餐次</span>
          <strong>{weekRecords.length}</strong>
          <small>覆盖 {recordedDays} / 7 天</small>
          <i className="metric-line" style={{ "--value": `${(recordedDays / 7) * 100}%` } as React.CSSProperties} />
        </article>
        <article>
          <span>日均热量估算</span>
          <strong>{avgCalories ? formatEstimatedRange(avgCalories) : "—"}</strong>
          <small>{avgCalories ? "kcal / 有记录日" : "等待记录"}</small>
          <i className="metric-line" style={{ "--value": `${Math.min(100, avgCalories / 18)}%` } as React.CSSProperties} />
        </article>
        <article>
          <span>蔬菜出现餐次</span>
          <strong>{mealsWithVegetables}</strong>
          <small>{weekRecords.length ? `${Math.round((mealsWithVegetables / weekRecords.length) * 100)}% 的餐次` : "等待记录"}</small>
          <i className="metric-line" style={{ "--value": `${weekRecords.length ? (mealsWithVegetables / weekRecords.length) * 100 : 0}%` } as React.CSSProperties} />
        </article>
        <article>
          <span>今日热量估算</span>
          <strong>{formatEstimatedRange(todayNutrition.calories)}</strong>
          <small>来自 {today.length} 条记录</small>
          <i className="metric-line" style={{ "--value": `${Math.min(100, todayNutrition.calories / 18)}%` } as React.CSSProperties} />
        </article>
      </div>

      <section className="memory-panel">
        <div className="memory-panel-heading">
          <div>
            <span className="micro-label">长期记忆 · 可确认、可停用</span>
            <h2>味衡正在记住什么</h2>
            <p>只有经过你确认的餐后反馈，才会改变之后的主建议。设置边界仍然优先。</p>
          </div>
          <div className="memory-count">
            <Brain size={19} strokeWidth={1.5} aria-hidden="true" />
            <span><b>{confirmedMemories.length}</b> 条已确认</span>
          </div>
        </div>

        <div className="memory-board">
          <div className="memory-candidates">
            <span className="micro-label">等待你确认</span>
            {memoryCandidates.length ? (
              memoryCandidates.map((memory) => (
                <article className={`memory-candidate ${memory.kind}`} key={memory.id}>
                  <div className="memory-candidate-copy">
                    <span>{memory.kind === "preference" ? "偏好信号" : "回避信号"} · {memory.tag}</span>
                    <h3>{memory.statement}</h3>
                    <p>{memory.detail}</p>
                  </div>
                  <div className="memory-actions">
                    <button type="button" onClick={() => onMemoryStatus(memory.id, "confirmed")}>
                      <Check size={14} />
                      写入记忆
                    </button>
                    <button type="button" onClick={() => onMemoryStatus(memory.id, "dismissed")}>
                      <X size={14} />
                      不采用
                    </button>
                  </div>
                </article>
              ))
            ) : (
              <div className="memory-empty">
                <LockKeyhole size={19} aria-hidden="true" />
                <div>
                  <strong>目前没有待确认的推断</strong>
                  <p>完成一次推荐餐，并在记录里选择“还想再吃”或“不太合适”，这里会出现记忆候选。</p>
                </div>
              </div>
            )}
          </div>

          <aside className="memory-confirmed">
            <span className="micro-label">正在影响推荐</span>
            {confirmedMemories.length ? (
              confirmedMemories.map((memory) => (
                <div className="confirmed-memory-row" key={memory.id}>
                  <i aria-hidden="true" />
                  <div>
                    <strong>{memory.statement}</strong>
                    <small>{memory.evidenceRecordIds.length} 次行为证据</small>
                  </div>
                  <button
                    type="button"
                    onClick={() => onMemoryStatus(memory.id, "dismissed")}
                    aria-label={`停用记忆：${memory.statement}`}
                  >
                    停用
                  </button>
                </div>
              ))
            ) : (
              <p className="memory-no-inference">尚未确认长期偏好。味衡不会根据一次饮食自动给你贴标签。</p>
            )}
            <div className="boundary-memory">
              <span>当前安全边界</span>
              <p>{settings.taboos.length ? settings.taboos.join("、") : "没有设置忌口"}</p>
              <small>来自个性设置，始终优先于学习记忆</small>
            </div>
          </aside>
        </div>
      </section>

      {weekRecords.length ? (
        <>
          <div className="insight-primary-grid">
            <section className="trend-card panel">
              <div className="panel-title-row">
                <div>
                  <span className="micro-label">热量节奏 · 估算</span>
                  <h2>七日记录节奏</h2>
                </div>
                <span className="chart-key"><i />每日记录合计</span>
              </div>
              <div className="insight-bar-chart">
                <div className="chart-axis" aria-hidden="true">
                  <span>{maxCalories}</span>
                  <span>{Math.round(maxCalories / 2)}</span>
                  <span>0</span>
                </div>
                <div className="bars-area">
                  <div className="axis-lines" aria-hidden="true"><i /><i /><i /></div>
                  {week.map((day, index) => (
                    <div className="insight-bar-column" key={day.date}>
                      <span className="insight-bar-value">{day.nutrition.calories || "—"}</span>
                      <div className="insight-bar-track">
                        <span
                          className={index === 6 ? "is-today" : ""}
                          style={{ height: `${(day.nutrition.calories / maxCalories) * 100}%` }}
                        />
                      </div>
                      <small>{day.label}</small>
                    </div>
                  ))}
                </div>
              </div>
              <p className="disclaimer-line">
                <Info size={14} aria-hidden="true" />
                图表使用你记录的营养估算累加，不代表医学意义上的实际吸收量。
              </p>
            </section>

            <section className="macro-card dark-panel">
              <div className="panel-title-row">
                <div>
                  <span className="micro-label">营养结构 · 近七天</span>
                  <h2>三大营养素结构</h2>
                </div>
                <TrendingUp size={20} strokeWidth={1.5} aria-hidden="true" />
              </div>
              <div className="macro-visual">
                <div
                  className="macro-donut"
                  style={{
                    background: `conic-gradient(var(--acid) 0 ${macro.carbs}%, var(--tomato) ${macro.carbs}% ${macro.carbs + macro.protein}%, var(--paper) ${macro.carbs + macro.protein}% 100%)`,
                  }}
                  aria-label={`碳水 ${macro.carbs}%，蛋白质 ${macro.protein}%，脂肪 ${macro.fat}%`}
                >
                  <div>
                    <strong>{weekNutrition.calories}</strong>
                    <span>kcal 估算</span>
                  </div>
                </div>
                <div className="macro-legend">
                  <span><i className="carb" />碳水<b>{macro.carbs}%</b></span>
                  <span><i className="protein" />蛋白质<b>{macro.protein}%</b></span>
                  <span><i className="fat" />脂肪<b>{macro.fat}%</b></span>
                </div>
              </div>
              <p>结构来自餐食估算值，适合看趋势，不适合作为单餐精确判断。</p>
            </section>
          </div>

          <div className="insight-secondary-grid">
            <section className="structure-card panel">
              <div className="panel-title-row">
                <div>
                  <span className="micro-label">饮食结构</span>
                  <h2>饮食结构反馈</h2>
                </div>
                <Salad size={21} strokeWidth={1.5} aria-hidden="true" />
              </div>
              <div className="structure-rows">
                <div>
                  <span className="structure-icon acid"><Leaf size={18} /></span>
                  <div>
                    <strong>蔬菜覆盖</strong>
                    <p>
                      {mealsWithVegetables} / {weekRecords.length} 餐出现蔬菜或菌菇。
                      {mealsWithVegetables >= Math.ceil(weekRecords.length / 2)
                        ? "已经有不错的出现频率。"
                        : "下一餐可以优先加入一份蔬菜。"}
                    </p>
                  </div>
                </div>
                <div>
                  <span className="structure-icon tomato"><Sparkles size={18} /></span>
                  <div>
                    <strong>蛋白质来源</strong>
                    <p>
                      {mealsWithProtein} 餐包含蛋、肉、豆腐、虾或奶类。种类可以继续轮换，让选择更丰富。
                    </p>
                  </div>
                </div>
                <div>
                  <span className="structure-icon paper"><CalendarCheck2 size={18} /></span>
                  <div>
                    <strong>重复与节奏</strong>
                    <p>
                      {repeatedMeals
                        ? `近 7 天有 ${repeatedMeals} 次餐名重复。偶尔重复能降低决策成本。`
                        : "近 7 天没有相同餐名。变化丰富，也可以保留熟悉的高效选项。"}
                    </p>
                  </div>
                </div>
              </div>
            </section>

            <section className="meal-mix-card panel">
              <span className="micro-label">餐次分布</span>
              <h2>餐次分布</h2>
              <div className="meal-type-chart">
                {typeCounts.map((item) => {
                  const percentage = weekRecords.length ? Math.round((item.count / weekRecords.length) * 100) : 0;
                  return (
                    <div key={item.type}>
                      <div>
                        <span>{item.type}</span>
                        <b>{item.count} 餐</b>
                      </div>
                      <i>
                        <span style={{ width: `${percentage}%` }} />
                      </i>
                      <small>{percentage}%</small>
                    </div>
                  );
                })}
              </div>
              <div className="next-action-note">
                <span>{settings.displayName} 的当前目标</span>
                <strong>{goalLabels[settings.goal]}</strong>
                <button type="button" onClick={onDecide}>
                  根据反馈决定下一餐 <ArrowUpRight size={15} />
                </button>
              </div>
            </section>
          </div>
        </>
      ) : (
        <section className="insights-empty panel">
          <div className="insights-empty-graphic" aria-hidden="true">
            <span /><span /><span /><span /><span /><span /><span />
          </div>
          <span className="micro-label">NO DATA, NO JUDGEMENT</span>
          <h2>有记录之后，反馈才有意义。</h2>
          <p>添加第一餐后，这里会出现七日节奏、营养结构和饮食构成。味衡不会给没有数据的生活编造结论。</p>
          <button className="button button-primary" type="button" onClick={onAdd}>添加第一餐</button>
        </section>
      )}

      <div className="insights-footer-note">
        <Info size={16} aria-hidden="true" />
        <p>
          味衡是饮食决策辅助工具，不提供医疗诊断或疾病治疗建议。所有营养数据均为根据餐食组合形成的估算值。
        </p>
      </div>
    </div>
  );
}
