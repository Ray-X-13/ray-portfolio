import { useEffect, useState } from "react";
import { CheckCircle2, Info } from "lucide-react";
import { Layout } from "./components/Layout";
import { RecordModal } from "./components/RecordModal";
import { defaultSettings } from "./data/meals";
import {
  demoRecords,
  loadMemories,
  loadRecords,
  loadSettings,
  resetAllData,
  saveMemories,
  saveRecords,
  saveSettings,
} from "./lib/storage";
import { deriveMemories } from "./lib/memory";
import { generateRecommendation } from "./lib/recommendationService";
import type {
  DecisionInput,
  Meal,
  MealRecord,
  MemoryEntry,
  Page,
  Recommendation,
  UserSettings,
} from "./types";
import { HomePage } from "./components/HomePage";
import { DecisionPage } from "./pages/DecisionPage";
import { RecordsPage } from "./pages/RecordsPage";
import { InsightsPage } from "./pages/InsightsPage";
import { SettingsPage } from "./pages/SettingsPage";

const pages: Page[] = ["home", "decide", "records", "insights", "settings"];

function pageFromHash(): Page {
  const hash = window.location.hash.replace(/^#\/?/, "");
  return pages.includes(hash as Page) ? (hash as Page) : "home";
}

function inferCurrentMealType(): MealRecord["mealType"] {
  const hour = new Date().getHours();
  if (hour < 10) return "早餐";
  if (hour < 15) return "午餐";
  if (hour < 21) return "晚餐";
  return "加餐";
}

type ToastState = { message: string; kind: "success" | "info" } | null;

export default function App() {
  const [page, setPage] = useState<Page>(pageFromHash);
  const [settings, setSettings] = useState<UserSettings>(loadSettings);
  const [records, setRecords] = useState<MealRecord[]>(loadRecords);
  const [memories, setMemories] = useState<MemoryEntry[]>(loadMemories);
  const [recordDraft, setRecordDraft] = useState<Partial<MealRecord> | null>(null);
  const [toast, setToast] = useState<ToastState>(null);

  useEffect(() => {
    const onHashChange = () => {
      setPage(pageFromHash());
      window.scrollTo({ top: 0, behavior: "smooth" });
    };
    window.addEventListener("hashchange", onHashChange);
    return () => window.removeEventListener("hashchange", onHashChange);
  }, []);

  useEffect(() => {
    saveRecords(records);
    setMemories((previous) => deriveMemories(records, previous));
  }, [records]);

  useEffect(() => {
    saveMemories(memories);
  }, [memories]);

  useEffect(() => {
    const titles: Record<Page, string> = {
      home: "今日",
      decide: "决定一餐",
      records: "饮食记录",
      insights: "饮食反馈",
      settings: "个性设置",
    };
    document.title = `${titles[page]}｜味衡 WEIHENG`;
  }, [page]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 3200);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const navigate = (nextPage: Page) => {
    setPage(nextPage);
    window.location.hash = nextPage === "home" ? "" : nextPage;
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleRecommend = async (input: DecisionInput): Promise<{
    recommendation: Recommendation | null;
    warning?: string;
  }> => {
    const recentMeals = records
      .slice()
      .sort((a, b) => b.date.localeCompare(a.date))
      .slice(0, 5)
      .map((record) => record.title);
    const result = await generateRecommendation(input, settings, recentMeals, memories);
    return {
      recommendation: result.recommendation,
      warning: result.warning,
    };
  };

  const openBlankRecord = () => {
    setRecordDraft({
      date: new Date().toISOString().slice(0, 10),
      mealType: inferCurrentMealType(),
      origin: "manual",
    });
  };

  const acceptMeal = (meal: Meal) => {
    setRecordDraft({
      title: meal.name,
      date: new Date().toISOString().slice(0, 10),
      mealType: inferCurrentMealType(),
      ingredients: meal.ingredients,
      note: "由味衡建议，营养值为估算。",
      nutrition: meal.nutrition,
      sourceTags: meal.tags,
      origin: "recommendation",
    });
  };

  const handleSaveRecord = (record: MealRecord) => {
    setRecords((previous) => {
      const exists = previous.some((item) => item.id === record.id);
      return exists
        ? previous.map((item) => (item.id === record.id ? record : item))
        : [record, ...previous];
    });
    setRecordDraft(null);
    setToast({
      message:
        record.origin === "recommendation" && record.satisfaction !== "okay"
          ? `${record.title}已保存，餐后反馈已用于更新味衡记忆`
          : `${record.title}已${records.some((item) => item.id === record.id) ? "更新" : "保存"}`,
      kind: "success",
    });
  };

  const handleDeleteRecord = (id: string) => {
    setRecords((previous) => previous.filter((record) => record.id !== id));
    setToast({ message: "记录已删除", kind: "info" });
  };

  const handleSaveSettings = (nextSettings: UserSettings) => {
    setSettings(nextSettings);
    const saved = saveSettings(nextSettings);
    setToast({
      message: saved ? "设置已保存，将用于下一次推荐" : "设置已更新，但浏览器未允许持久化",
      kind: saved ? "success" : "info",
    });
  };

  const handleMemoryStatus = (id: string, status: MemoryEntry["status"]) => {
    setMemories((previous) =>
      previous.map((memory) =>
        memory.id === id ? { ...memory, status, updatedAt: new Date().toISOString() } : memory,
      ),
    );
    setToast({
      message: status === "confirmed" ? "已写入长期记忆，将影响下一次推荐" : "已忽略这条记忆候选",
      kind: status === "confirmed" ? "success" : "info",
    });
  };

  const handleReset = () => {
    resetAllData();
    setSettings(defaultSettings);
    setRecords(demoRecords);
    setMemories([]);
    setToast({ message: "已恢复初始示例数据", kind: "info" });
  };

  const renderPage = () => {
    switch (page) {
      case "decide":
        return (
          <DecisionPage
            settings={settings}
            memories={memories}
            recentMeals={records.slice(0, 5).map((record) => record.title)}
            onRecommend={handleRecommend}
            onAccept={acceptMeal}
            onOpenSettings={() => navigate("settings")}
          />
        );
      case "records":
        return (
          <RecordsPage
            records={records}
            onAdd={openBlankRecord}
            onEdit={setRecordDraft}
            onDelete={handleDeleteRecord}
          />
        );
      case "insights":
        return (
          <InsightsPage
            records={records}
            settings={settings}
            memories={memories}
            onMemoryStatus={handleMemoryStatus}
            onDecide={() => navigate("decide")}
            onAdd={openBlankRecord}
          />
        );
      case "settings":
        return (
          <SettingsPage
            settings={settings}
            onSave={handleSaveSettings}
            onReset={handleReset}
          />
        );
      case "home":
      default:
        return (
          <HomePage
            settings={settings}
            records={records}
            memories={memories}
            onNavigate={navigate}
            onAddRecord={openBlankRecord}
          />
        );
    }
  };

  return (
    <>
      <a className="skip-link" href="#main-content">跳到主要内容</a>
      <Layout page={page} displayName={settings.displayName} onNavigate={navigate}>
        {renderPage()}
      </Layout>
      <RecordModal
        draft={recordDraft}
        onClose={() => setRecordDraft(null)}
        onSave={handleSaveRecord}
      />
      {toast ? (
        <div className={`toast toast-${toast.kind}`} role="status">
          {toast.kind === "success" ? <CheckCircle2 size={18} /> : <Info size={18} />}
          {toast.message}
        </div>
      ) : null}
    </>
  );
}
