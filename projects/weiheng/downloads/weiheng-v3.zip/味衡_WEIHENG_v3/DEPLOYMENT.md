# 味衡部署说明

## 1. 构建

要求 Node.js 20+，推荐 Node.js 22。

```bash
npm install
npm test
npm run build
```

构建成功后会生成 `dist/`。纯静态版本只使用本地规则，不依赖数据库或后端。

当前已有 GitHub 源码仓库：

```text
https://github.com/Ray-X-13/weiheng-ai
```

原 GitHub Pages 地址 `https://ray-x-13.github.io/weiheng-ai/` 于 2026-11-22 检查返回 HTTP 404，不能作为可访问 Demo。请勿在报名材料中填写该地址，除非你确认重新发布成功。

## 2. Gitee 仓库

先在 Gitee 创建空仓库，并确认没有勾选自动生成 README，然后在项目根目录执行：

```bash
cd 味衡_WEIHENG_v3
git init
git add .
git commit -m "feat: complete WeiHeng AI food decision demo"
git branch -M main
git remote add origin https://gitee.com/<your-name>/<repo>.git
git push -u origin main
```

这一步需要你的 Gitee 账号或 SSH Key，当前交付没有代为公开推送。

## 3. 静态托管推荐

### 方案 A：Netlify Drop（最快）

1. `npm run build`
2. 打开 Netlify Drop。
3. 上传整个 `dist/` 目录。
4. 获得公开 URL。
5. 在手机和桌面分别验证首页、推荐、记录与反馈。

注意：拖拽上传 `dist/` 内容到公开平台属于公开发布动作，需要本人确认并完成账号授权。

### 方案 B：Cloudflare Pages

1. 在 Cloudflare Pages 新建项目。
2. 如果连接 Git 仓库，构建命令填写 `npm run build`。
3. 输出目录填写 `dist`。
4. 部署后检查页面与静态资源路径。

Vite 已配置 `base: "./"`，适用于静态站点和子路径。

### 方案 C：Vercel

1. 导入 Git 仓库。
2. Framework 选择 Vite。
3. Build Command：`npm run build`
4. Output Directory：`dist`
5. 发布。

### 关于 Gitee Pages

Gitee Pages 的公开服务可用性可能随平台政策变化。如果当前账号没有可用的 Pages 服务，不要虚构 Gitee 网页链接。可继续使用 Gitee 存放和协作源码，再将 `dist/` 托管到其他静态平台。

## 4. 可选真实模型部署

默认静态站点不需要模型服务。若要启用真实模型：

1. 将 `server/ai-proxy.mjs` 改造成目标平台的 Serverless Function，或运行在长期在线 Node.js 服务中。
2. 在托管平台设置：

```text
AI_API_KEY=<服务端密钥>
AI_BASE_URL=<OpenAI-compatible API 根地址>
AI_MODEL=<模型名称>
ALLOWED_ORIGIN=<前端公开域名>
```

3. 在静态构建环境中设置：

```text
VITE_AI_ENDPOINT=https://<your-api-host>/api/recommend
```

4. 重新构建并部署。

绝不能在 `VITE_*` 变量或任何前端源码中存放模型密钥。

## 5. 发布后验收清单

- [ ] 首屏和品牌资源正常加载
- [ ] 生成一次本地规则推荐
- [ ] 推荐来源显示“本地规则推荐”
- [ ] 推荐转为记录并保存
- [ ] 刷新后记录保留
- [ ] 修改和删除记录
- [ ] 反馈图表随记录变化
- [ ] 保存设置后再进入推荐页，设置已带入
- [ ] 390px 移动端无横向滚动
- [ ] 页面控制台无错误
- [ ] README 中替换为真实公开 URL
