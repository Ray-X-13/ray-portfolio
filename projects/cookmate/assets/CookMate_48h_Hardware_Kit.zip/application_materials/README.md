# CookMate 报名直接使用材料

## 推荐组合

1. 报名正文：[main_answer_900.txt](main_answer_900.txt)，或 [07_APPLICATION_COPY.md](../07_APPLICATION_COPY.md) 的“推荐主版本”。
2. 一页方案卡：[application_build_card.png](../hardware/renders/application_build_card.png)。
3. 可下载硬件包：[CookMate_48h_Hardware_Kit.zip](../11_WEBSITE/assets/CookMate_48h_Hardware_Kit.zip)。
4. 公开项目页或 GitHub/Gitee 链接：发布后再填，当前尚未部署。

如需直接上传附件，可使用 [CookMate_DDC2026_Application_Kit.zip](CookMate_DDC2026_Application_Kit.zip)，其中已经包含正文、方案卡、视频分镜和硬件包。

## 极短字段

使用 [short_answer_450.txt](short_answer_450.txt)。实际约 300 个可见字符，适合字数很紧的“48 小时要做什么”。

## 附件说明

使用 [attachment_description.txt](attachment_description.txt)。不要声称这些文件是已完成实物，它们是 48 小时内可打印、接线和验证的工程材料。

## 发布顺序

1. 创建公开 GitHub/Gitee 仓库，根目录放本文件夹上一层的内容；
2. 用 `11_WEBSITE/` 发布项目页；
3. 验证匿名浏览器可打开；
4. 验证硬件包可下载、STL 可导入；
5. 再填入报名表。

账号登录和公开发布需要用户授权，本环境未执行。
