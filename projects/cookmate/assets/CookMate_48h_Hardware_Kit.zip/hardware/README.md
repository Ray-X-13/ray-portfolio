# CookMate 48 小时硬件包

这是 CookMate V2 外露工程样机的可加工、可接线材料，不是已完成实物。

![工程样机](renders/engineering_prototype.png)

## 核心选择

- 固定 5.5 英寸 HDMI 屏幕；
- 单轴相机云台，在切配区和锅具区之间转；
- USB 麦克风扬声器；
- USB HID 三键；
- RDK X5 作为全部业务状态和本地感知的主控；
- 舵机独立供电，仅 PWM 信号来自 X5 Pin 33。

这样屏幕和 HDMI 线不参与旋转，减少结构风险。相机云台只负责覆盖两个操作位置，不假装人脸或拟人动作。

## 先做什么

1. 阅读 [ASSEMBLY_GUIDE.md](ASSEMBLY_GUIDE.md)。
2. 按 [CAMERA_PLACEMENT.md](CAMERA_PLACEMENT.md) 在两块操作区上标定相机。
3. 打印 [1:1 纸模板](templates/base_plate_1to1.svg)；确保 A4 100%。用 100 mm 标尺校准。
4. 按 [BOM.csv](BOM.csv) 清点/采购。
5. 用真实屏幕、相机、声卡、三键、舵机和 2020 型材在纸面上试摆。
6. 修改 STL 参数或直接修改 `cad/cookmate_params.scad`。
7. 再打印底座、斜托、立柱夹和相机 cradle。
8. 先给每个外设单独供电/接入，运行 `bringup/` 下测试。
9. 最后接入统一状态机。

## 打印件

| 文件 | 作用 |
| --- | --- |
| `cad/01_base_tray.stl` | 底座托盘 |
| `cad/02_screen_bezel.stl` | 屏幕边框/斜托快速件 |
| `cad/03_mast_clamp.stl` | 2020 型材立柱夹 |
| `cad/04_servo_camera_cradle.stl` | 舵机与相机 cradle |
| `cad/05_keypad_bezel.stl` | USB HID 三键面板 |

这些 STL 由简单体块生成，适合快速装配，不建议直接作为商业产品结构。实际孔位必须用卡尺复核。

## 接线与安全

![供电与接口](renders/wiring.png)

- X5: 5V/5A 独立电源；
- 屏幕按模块要求独立供电；
- 舵机：独立 5V/2A，加保险/限流；
- 舵机信号：X5 Pin 33 PWM；
- 所有电源共地；
- 不在带电状态插拔 MIPI；
- 设备远离明火、热油和溅水区；
- 不声称防水或食品安全检测。

## 快速烟测

```bash
bash bringup/check_environment.sh
cat /proc/asound/cards
bash bringup/test_audio.sh
python3 bringup/test_camera.py
python3 bringup/test_servo_safe.py
```

只有在真实 RDK 和对应外设上运行这些脚本，结果才算硬件测试。

## 生成图与 STL

```bash
python3 generate_assets.py
```

会重新生成 `renders/` 和 `cad/*.stl`。这些是按当前设计包络生成的快速件。
