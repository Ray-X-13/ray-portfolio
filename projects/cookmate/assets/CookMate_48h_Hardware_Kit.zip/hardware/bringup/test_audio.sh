#!/usr/bin/env bash
set -euo pipefail

echo "-- ALSA cards --"
cat /proc/asound/cards
echo
echo "-- playback devices --"
aplay -l || true
echo
echo "-- capture devices --"
arecord -l || true
echo
echo "Run a 5-second capture after selecting the USB card:"
echo "  arecord -D plughw:CARD,DEVICE -f S16_LE -r 16000 -c 1 -d 5 /tmp/cookmate-mic.wav"
echo "  aplay -D plughw:CARD,DEVICE /tmp/cookmate-mic.wav"
echo
echo "Record the actual CARD and DEVICE above; do not hardcode hw:0."

