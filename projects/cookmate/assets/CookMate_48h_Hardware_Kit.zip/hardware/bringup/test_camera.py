#!/usr/bin/env python3
from __future__ import annotations

import argparse
import time


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", type=int, default=0)
    parser.add_argument("--seconds", type=float, default=10.0)
    parser.add_argument("--width", type=int, default=1280)
    parser.add_argument("--height", type=int, default=720)
    args = parser.parse_args()

    try:
        import cv2
    except Exception as exc:
        raise SystemExit("OpenCV is not installed. Install the RDK image package first.") from exc

    cap = cv2.VideoCapture(args.device)
    if not cap.isOpened():
        raise SystemExit(f"/dev/video{args.device} did not open")
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, args.width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, args.height)

    frames = 0
    reads = 0
    started = time.monotonic()
    try:
        while time.monotonic() - started < args.seconds:
            ok, frame = cap.read()
            reads += 1
            if ok and frame is not None:
                frames += 1
                if frames == 1:
                    h, w = frame.shape[:2]
                    print(f"first frame: {w}x{h}")
            else:
                print("read failed")
                time.sleep(0.1)
    finally:
        cap.release()
    print(f"frames={frames} reads={reads} seconds={time.monotonic() - started:.2f}")
    if frames == 0:
        raise SystemExit("no frames received")


if __name__ == "__main__":
    main()

