#!/usr/bin/env bash
set -euo pipefail

echo "== CookMate RDK bring-up =="
date --iso-8601=seconds 2>/dev/null || date
echo
echo "-- OS / kernel --"
uname -a
cat /etc/version 2>/dev/null || true
echo
echo "-- Board info --"
cat /sys/class/boardinfo/soc_name /sys/class/socinfo/soc_name 2>/dev/null | tr -d '\0' || true
echo
echo "-- Memory / disk --"
free -h || true
df -h /
echo
echo "-- Thermal --"
for zone in /sys/class/thermal/thermal_zone*/temp; do
  [ -r "$zone" ] && printf '%s: %s\n' "$zone" "$(cat "$zone")"
done
echo
echo "-- Audio --"
cat /proc/asound/cards 2>/dev/null || true
ls /dev/snd 2>/dev/null || true
echo
echo "-- Camera --"
ls -l /dev/video* 2>/dev/null || true
echo
echo "-- 40-pin helper --"
python3 - <<'PY'
try:
    import Hobot.GPIO as GPIO
    print("Hobot.GPIO: OK")
    print("BOARD reference:", GPIO.BOARD)
except Exception as exc:
    print("Hobot.GPIO unavailable:", repr(exc))
PY

