#!/usr/bin/env python3
"""Conservative single-servo test for RDK X5.

Wiring:
  servo signal -> BOARD pin 33 (PWM7)
  servo +5V    -> isolated 5V/2A supply
  servo GND    -> isolated supply GND AND X5 GND

Do not power the servo from a 40-pin supply pin.
"""

from __future__ import annotations

import argparse
import time


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pin", type=int, default=33)
    parser.add_argument("--center", type=float, default=90.0)
    parser.add_argument("--sweep", type=float, default=20.0)
    parser.add_argument("--step", type=float, default=5.0)
    parser.add_argument("--delay", type=float, default=0.45)
    args = parser.parse_args()

    try:
        import Hobot.GPIO as GPIO
    except Exception as exc:
        raise SystemExit(
            "Hobot.GPIO is not available. Run only on a compatible RDK image; "
            "there is no desktop simulation for this physical test."
        ) from exc

    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BOARD)
    GPIO.setup(args.pin, GPIO.OUT)

    pwm = GPIO.PWM(args.pin, 50)
    pwm.start(0)

    def goto(angle: float) -> None:
        safe_angle = clamp(angle, args.center - args.sweep, args.center + args.sweep)
        duty = 2.5 + safe_angle / 18.0
        print(f"angle={safe_angle:.1f} duty={duty:.2f}%")
        pwm.ChangeDutyCycle(duty)
        time.sleep(args.delay)

    try:
        # Start at center and intentionally remain inside a small safe range.
        goto(args.center)
        for delta in (-args.sweep, args.sweep):
            for angle in range(0, int(args.sweep) + 1, int(args.step)):
                goto(args.center + (delta if delta < 0 else 0) + (angle if delta < 0 else angle))
                time.sleep(0.05)
        goto(args.center)
    finally:
        pwm.ChangeDutyCycle(0)
        time.sleep(0.2)
        pwm.stop()
        GPIO.cleanup()
        print("Servo stopped and GPIO cleaned up.")


if __name__ == "__main__":
    main()

