# CAD 与打印文件

这里包含 CookMate 48 小时外露式工程样机的**快速装配件**，不是量产外壳。

## 文件

- `cookmate_params.scad`：Fusion 360 / OpenSCAD 可复用的参数源；
- `01_base_tray.stl`：底座托盘，容纳 X5、USB HUB 和安装柱；
- `02_screen_bezel.stl`：5-5.5 英寸屏幕前框概念件；
- `03_mast_clamp.stl`：120 mm 2020 型材立柱夹；
- `04_servo_camera_cradle.stl`：MG90S 与 UVC 相机头托架；
- `05_keypad_bezel.stl`：USB HID 三键面板。

## 重要限制

屏幕、相机和舵机的品牌尺寸不同。所有 STL 都按以下**设计包络**生成：

- 底座：180×135×36 mm；
- 屏幕可视区：约 140×78 mm；
- 舵机：MG90S 类；
- 立柱：20×20 mm；
- 相机：常见 30×30 mm UVC 模组。

实际到货后必须先量孔距和厚度。STL 是“快速找装配关系”，不是“买任何屏幕都能装”。

## 打印建议

```text
材料：PETG
层高：0.20 mm
墙数：3-4
填充：20-30% gyroid
支撑：仅悬垂区域
关键受力件：增加壁数或金属背板
```

## Fusion 360 导入

1. Insert → Mesh → 选择 STL；
2. 单位选择 mm；
3. 作为 Mesh Body 用于结构占位；
4. 根据实物测量重新画 Sketch/Extrude；
5. 不在 Mesh 上直接做精细孔位；
6. 参数化建模顺序见项目 [05_PRODUCT_DESIGN.md](../../05_PRODUCT_DESIGN.md)。

## 爆炸视图

渲染图 `../renders/exploded_prototype.png` 可直接用于报名附件或讲解。它展示：

底座 → X5 → 屏幕/斜托 → 三键 → 立柱 → 舵机/相机。

这个结构不包含行星齿轮组。若课程另设行星齿轮任务，需要独立建模。

