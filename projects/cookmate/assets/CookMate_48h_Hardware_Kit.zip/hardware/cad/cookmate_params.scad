// CookMate quick-fit bench prototype
// Units: millimetres. VERIFY ALL COMPONENT DIMENSIONS BEFORE PRINTING.
$fn = 40;

base_w = 180;
base_d = 135;
base_h = 36;
wall = 4;

screen_outer_w = 150;
screen_outer_h = 96;
screen_t = 12;
screen_angle = 15;

screen_active_w = 121;   // measure actual visible area
screen_active_h = 68;    // measure actual visible area

mast_w = 20;
mast_d = 20;
mast_h = 120;

servo_body_w = 23;
servo_body_d = 12.5;
servo_body_h = 29;
servo_shaft_offset = 5;

camera_w = 32;
camera_d = 32;
camera_h = 18;

keypad_w = 88;
keypad_d = 52;
keypad_h = 10;

// Reference solids for planning. Split and reinforce before final print.
module base_tray_reference() {
    difference() {
        cube([base_w, base_d, base_h]);
        translate([wall, wall, wall])
            cube([base_w - 2*wall, base_d - 2*wall, base_h]);
    }
}

module screen_frame_reference() {
    difference() {
        cube([screen_outer_w, screen_outer_h, screen_t]);
        translate([8, 8, -1])
            cube([screen_outer_w - 16, screen_outer_h - 16, screen_t + 2]);
    }
}

module servo_cradle_reference() {
    difference() {
        cube([52, 34, 39]);
        translate([5, 8, 4])
            cube([42, 26, 36]);
    }
}

// Optional: preview all reference parts.
// base_tray_reference();
// translate([0, 150, 0]) rotate([0, screen_angle, 0]) screen_frame_reference();
// translate([200, 0, 0]) servo_cradle_reference();
