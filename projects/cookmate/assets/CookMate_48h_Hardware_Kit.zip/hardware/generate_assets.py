from __future__ import annotations

import math
import struct
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
HARDWARE = ROOT / "hardware"
RENDERS = HARDWARE / "renders"
CAD = HARDWARE / "cad"
FONT_PATH = "/System/Library/Fonts/STHeiti Medium.ttc"

CREAM = "#F4EEE5"
PAPER = "#FFFCF7"
INK = "#1F282D"
MUTED = "#677177"
ORANGE = "#D66A3B"
ORANGE_DARK = "#9C4326"
ORANGE_PALE = "#F2D8C8"
GREEN = "#557B64"
GREEN_PALE = "#DDE9E0"
BLUE = "#3F6173"
BLUE_PALE = "#E6EEF1"
LINE = "#D8D1C7"
SCREEN = "#202A30"
WHITE = "#FFFFFF"


def font(size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(FONT_PATH, size=size, index=0)


def center_text(
    draw: ImageDraw.ImageDraw,
    xy: tuple[float, float],
    text: str,
    fnt: ImageFont.FreeTypeFont,
    fill: str = INK,
    spacing: int = 6,
) -> None:
    box = draw.multiline_textbbox((0, 0), text, font=fnt, spacing=spacing, align="center")
    w, h = box[2] - box[0], box[3] - box[1]
    draw.multiline_text(
        (xy[0] - w / 2, xy[1] - h / 2),
        text,
        font=fnt,
        fill=fill,
        spacing=spacing,
        align="center",
    )


def rounded(
    draw: ImageDraw.ImageDraw,
    box: tuple[int, int, int, int],
    fill: str,
    radius: int,
    outline: str | None = None,
    width: int = 1,
) -> None:
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def arrow(
    draw: ImageDraw.ImageDraw,
    start: tuple[int, int],
    end: tuple[int, int],
    color: str = MUTED,
    width: int = 5,
    head: int = 14,
    dashed: bool = False,
) -> None:
    x1, y1 = start
    x2, y2 = end
    dx, dy = x2 - x1, y2 - y1
    length = max(math.hypot(dx, dy), 1)
    ux, uy = dx / length, dy / length
    if dashed:
        pos = 0
        while pos < length - head:
            p2 = min(pos + 18, length - head)
            draw.line(
                [(x1 + ux * pos, y1 + uy * pos), (x1 + ux * p2, y1 + uy * p2)],
                fill=color,
                width=width,
            )
            pos += 30
    else:
        draw.line([start, (x2 - ux * head, y2 - uy * head)], fill=color, width=width)
    px, py = -uy, ux
    p1 = (x2 - ux * head + px * head * 0.62, y2 - uy * head + py * head * 0.62)
    p2 = (x2 - ux * head - px * head * 0.62, y2 - uy * head - py * head * 0.62)
    draw.polygon([end, p1, p2], fill=color)


def make_product() -> None:
    w, h = 1800, 1050
    image = Image.new("RGB", (w, h), CREAM)
    d = ImageDraw.Draw(image)
    d.ellipse((70, 30, 1040, 860), fill="#EEE2D2")
    d.ellipse((1080, 730, 1900, 1250), fill="#E8DCCB")
    d.rectangle((0, 860, w, h), fill="#CFBEA9")
    d.rectangle((0, 860, w, 878), fill="#EBDCCB")

    # Title and status.
    d.text((100, 82), "CookMate", font=font(60), fill=INK)
    d.text((103, 152), "48 小时可搭建的桌面工程样机", font=font(30), fill=MUTED)
    rounded(d, (103, 208, 430, 260), ORANGE, 24)
    center_text(d, (267, 234), "RDK X5 · 固定屏 · 单轴相机头", font(21), WHITE)

    # Work mat with two active zones.
    rounded(d, (1060, 710, 1650, 850), "#D77C53", 26)
    rounded(d, (1076, 727, 1634, 834), "#DF936D", 19)
    d.line((1338, 720, 1338, 840), fill="#F5D5C2", width=3)
    d.text((1115, 750), "切配区", font=font(24), fill=WHITE)
    d.text((1420, 750), "锅具区", font=font(24), fill=WHITE)
    d.ellipse((1185, 784, 1265, 824), fill="#F4E3D4")
    d.ellipse((1455, 780, 1570, 830), fill="#2E373C")

    # Base shadow.
    d.ellipse((220, 885, 990, 990), fill="#AD9B88")
    # Base top wedge and front.
    d.polygon([(260, 735), (865, 735), (925, 825), (205, 825)], fill="#FFF9F1")
    d.polygon([(205, 825), (925, 825), (900, 930), (235, 930)], fill="#F1E5D7")
    d.line([(260, 735), (865, 735), (925, 825), (900, 930), (235, 930), (205, 825), (260, 735)], fill="#C9B9A8", width=4)

    # Screen chassis on a 15 degree visual wedge.
    d.polygon([(318, 740), (760, 740), (790, 420), (360, 420)], fill="#E5D9CB")
    rounded(d, (285, 230, 805, 705), "#FFFDF9", 46, "#D2C4B4", 4)
    rounded(d, (320, 273, 770, 650), SCREEN, 33)
    # Fixed screen UI, no anthropomorphic face.
    d.text((358, 311), "STEP 2 / 6", font=font(22), fill="#F4A36D")
    d.text((358, 362), "切番茄", font=font(58), fill="#FFF0D3")
    d.text((358, 448), "切完说继续", font=font(28), fill="#E5DAC9")
    rounded(d, (355, 523, 731, 570), "#344149", 16)
    d.text((378, 535), "02:00", font=font(22), fill="#F7D49E")
    d.rectangle((355, 591, 665, 600), fill="#48545A")
    d.rectangle((355, 591, 536, 600), fill=ORANGE)
    d.text((356, 623), "麦克风在听", font=font(18), fill="#BFC7C8")

    # Front controls and speaker.
    d.ellipse((310, 820, 390, 900), fill="#813725", outline="#56251A", width=4)
    d.text((337, 850), "II", font=font(30), fill=WHITE)
    rounded(d, (415, 832, 520, 878), "#D9CEC0", 18)
    center_text(d, (467, 855), "重复", font(19), INK)
    rounded(d, (540, 832, 645, 878), "#D9CEC0", 18)
    center_text(d, (592, 855), "继续", font(19), INK)
    for i in range(7):
        d.ellipse((680 + i * 23, 844, 691 + i * 23, 866), fill="#536067")

    # Mast, servo and camera.
    d.line((815, 735, 815, 330), fill="#7F898C", width=18)
    rounded(d, (775, 680, 855, 755), "#B8C0C1", 18)
    d.ellipse((771, 266, 879, 374), fill="#B2BBBD", outline="#7E898C", width=4)
    d.ellipse((793, 288, 857, 352), fill="#3A454A")
    rounded(d, (714, 285, 780, 350), "#65747A", 22)
    d.ellipse((720, 297, 762, 339), fill="#9EB0B4")
    d.ellipse((731, 308, 751, 328), fill="#D9E4E3")
    d.arc((692, 285, 960, 450), 208, 330, fill=ORANGE, width=4)

    # Zone-switch direction.
    d.line((852, 366, 1010, 365), fill="#837B70", width=4)
    d.polygon([(1060, 365), (1037, 353), (1037, 377)], fill=ORANGE)
    d.line((1060, 365, 1320, 280), fill="#A69784", width=3)

    labels = [
        ((839, 250), (1030, 128), "单轴相机头\n在切配/锅具区之间转"),
        ((912, 776), (1090, 570), "实体暂停键\n湿手可直接按"),
        ((790, 710), (980, 910), "RDK X5 与供电\n藏在底座内"),
        ((635, 908), (900, 985), "三键输入 + 近场扬声器"),
    ]
    for start, end, label in labels:
        d.line([start, end], fill="#8A7D6E", width=3)
        d.ellipse((start[0] - 6, start[1] - 6, start[0] + 6, start[1] + 6), fill=ORANGE)
        x, y = end
        d.multiline_text((x + 12, y - 32), label, font=font(24), fill=INK, spacing=6)

    d.text((100, 975), "工程样机方向：先保证能打印、能接线、能现场按钮降级，再做美化外壳。", font=font(24), fill="#5D5247")
    image.save(RENDERS / "engineering_prototype.png", quality=95)


def make_exploded() -> None:
    w, h = 1800, 1120
    image = Image.new("RGB", (w, h), PAPER)
    d = ImageDraw.Draw(image)
    d.text((72, 52), "CookMate 外露式工程样机拆解", font=font(45), fill=INK)
    d.text((74, 110), "48h 首选版本不做封闭整壳；标准件 + 可打印夹具，便于测量、接线和维修", font=font(23), fill=MUTED)

    # Base plate.
    d.polygon([(210, 800), (885, 800), (965, 735), (290, 735)], fill="#E9DED0", outline="#BDB0A0")
    d.polygon([(210, 800), (885, 800), (885, 855), (210, 855)], fill="#D9CCBC", outline="#BDB0A0")
    d.polygon([(885, 800), (965, 735), (965, 790), (885, 855)], fill="#CBBBA8", outline="#BDB0A0")
    d.text((300, 785), "01  底座托盘  180 x 135 x 38 mm", font=font(22), fill=INK)

    # X5 board.
    rounded(d, (320, 690, 620, 775), "#416B59", 10, "#274B3D", 3)
    d.text((350, 715), "RDK X5", font=font(23), fill=WHITE)
    d.text((350, 748), "85 x 56 mm", font=font(17), fill="#DDE9E1")

    # Screen assembly.
    rounded(d, (250, 385, 690, 625), "#2D383E", 26, "#65747A", 4)
    rounded(d, (280, 410, 660, 590), "#0F171B", 16)
    d.text((306, 442), "STEP 2 / 6", font=font(18), fill="#F5A16A")
    d.text((306, 480), "切番茄", font=font(34), fill="#FFF1D2")
    d.text((306, 540), "02:00 · 说继续", font=font(18), fill="#D7CCBB")
    d.polygon([(250, 625), (690, 625), (745, 670), (305, 670)], fill="#D9CCBC", outline="#BDB0A0")
    d.text((300, 640), "02  5.5 寸 HDMI 屏 + 15° 斜托", font=font(21), fill=INK)

    # Mast and camera.
    d.rectangle((790, 390, 822, 745), fill="#768387", outline="#4A585D", width=3)
    rounded(d, (760, 345, 852, 420), "#B2BCBE", 15, "#748185", 3)
    rounded(d, (728, 285, 884, 365), "#D7DDDC", 25, "#748185", 3)
    d.ellipse((750, 308, 810, 368), fill="#283439")
    d.ellipse((765, 323, 795, 353), fill="#A8B8BB")
    d.text((685, 250), "03  60 mm 相机云台 + 单轴舵机", font=font(21), fill=INK)

    # Button keypad.
    rounded(d, (430, 720, 640, 790), "#F6EFE5", 14, "#B8AA99", 3)
    for x, label, color in [(455, "重复", "#D6C9B9"), (515, "暂停", ORANGE), (575, "继续", "#D6C9B9")]:
        rounded(d, (x, 735, x + 48, 778), color, 10)
        center_text(d, (x + 24, 756), label, font(15), WHITE if label == "暂停" else INK)
    d.text((438, 805), "04  USB HID 三键，不改 GPIO 按键电平", font=font(20), fill=INK)

    # Wiring.
    d.line((690, 495, 790, 495, 790, 610), fill=BLUE, width=5)
    d.line((620, 690, 790, 690, 790, 745), fill="#6B7F67", width=5)
    d.line((640, 748, 760, 748, 850, 700), fill="#9C4326", width=5)
    d.text((1010, 452), "05  总线", font=font(29), fill=INK)
    for y, text, color in [
        (500, "HDMI：屏幕", BLUE),
        (548, "USB：相机 / 音频 / 三键", GREEN),
        (596, "PWM Pin 33：云台信号", ORANGE_DARK),
        (644, "独立 5V/2A：舵机电源", ORANGE_DARK),
        (692, "共地，不共电源", "#9C4326"),
    ]:
        d.ellipse((1013, y - 8, 1029, y + 8), fill=color)
        d.text((1043, y - 15), text, font=font(21), fill=INK)

    # Assembly order and dimensions.
    rounded(d, (1090, 770, 1725, 1010), "#F1EAE0", 24)
    d.text((1120, 800), "装配顺序", font=font(24), fill=INK)
    steps = [
        "1. 打印底座/斜托/相机夹具，先试装实物尺寸",
        "2. 固定 X5、屏幕和 USB HUB，再接 USB HID 三键",
        "3. 2020 立柱固定到托盘，安装舵机与相机头",
        "4. 相机只转，屏幕不转，线缆留 20 mm 服务环",
        "5. 独立舵机电源与 X5 共地；上电回中",
    ]
    for i, step in enumerate(steps):
        d.text((1120, 847 + i * 30), step, font=font(17), fill=MUTED)

    d.text((72, 1060), "尺寸为快速样机包络；屏幕、相机、舵机到货后必须复测。STL 是夹具与基础件，不是量产外壳。", font=font(21), fill=MUTED)
    image.save(RENDERS / "exploded_prototype.png", quality=95)


def make_wiring() -> None:
    w, h = 1800, 1100
    image = Image.new("RGB", (w, h), PAPER)
    d = ImageDraw.Draw(image)
    d.text((72, 48), "CookMate 供电与接口", font=font(45), fill=INK)
    d.text((74, 106), "48h 工程样机接线：USB 外设优先，只有舵机使用 40Pin PWM", font=font(23), fill=MUTED)

    # X5 center.
    rounded(d, (590, 430, 1010, 735), "#315846", 36, "#264737", 4)
    d.text((655, 472), "RDK X5 8GB", font=font(39), fill=WHITE)
    d.text((655, 527), "5V/5A", font=font(24), fill="#E0ECE3")
    d.text((655, 570), "HDMI · USB · PWM", font=font(21), fill="#E0ECE3")
    d.text((655, 628), "菜谱状态 / 计时 / 日志", font=font(20), fill="#C5D8CA")

    # Power adapters.
    rounded(d, (90, 240, 390, 340), "#F4E6DA", 25, ORANGE, 3)
    d.text((123, 268), "X5 电源适配器", font=font(25), fill=INK)
    d.text((124, 307), "5V / 5A · 独立 Type-C", font=font(18), fill=MUTED)
    arrow(d, (390, 290), (590, 510), ORANGE_DARK, 5)

    rounded(d, (90, 780, 390, 900), "#F5DDD8", 25, "#B84B3D", 4)
    d.text((122, 807), "舵机电源", font=font(25), fill="#8F3027")
    d.text((122, 848), "5V / 2A + 保险/限流", font=font(18), fill=MUTED)
    d.text((122, 874), "不要从 40Pin 取电", font=font(18), fill="#8F3027")

    # Outputs.
    rounded(d, (1220, 185, 1680, 280), "#EAF1F4", 22, BLUE, 3)
    d.text((1250, 210), "HDMI 小屏", font=font(25), fill=INK)
    d.text((1250, 247), "步骤 / 计时 / 故障", font=font(18), fill=MUTED)
    arrow(d, (1010, 470), (1220, 245), BLUE, 5)

    rounded(d, (1220, 355, 1680, 450), "#E8F0EA", 22, GREEN, 3)
    d.text((1250, 380), "USB 麦克风 + 扬声器", font=font(25), fill=INK)
    d.text((1250, 416), "UAC 免驱 / 声卡号需记录", font=font(18), fill=MUTED)
    arrow(d, (1010, 520), (1220, 410), GREEN, 5)

    rounded(d, (1220, 525, 1680, 620), "#EAF1F4", 22, BLUE, 3)
    d.text((1250, 550), "USB 广角相机", font=font(25), fill=INK)
    d.text((1250, 587), "/dev/video0 · 手部 ROI", font=font(18), fill=MUTED)
    arrow(d, (1010, 590), (1220, 580), BLUE, 5)

    rounded(d, (1220, 695, 1680, 790), "#F6EEE4", 22, "#B8AA99", 3)
    d.text((1250, 720), "USB HID 三键", font=font(25), fill=INK)
    d.text((1250, 757), "暂停 / 重复 / 继续", font=font(18), fill=MUTED)
    arrow(d, (1010, 690), (1220, 742), "#8C7F70", 5)

    rounded(d, (520, 805, 1085, 960), "#F5DDD8", 28, "#B84B3D", 4)
    d.text((555, 832), "相机云台舵机", font=font(26), fill="#8F3027")
    d.text((555, 875), "PWM Pin 33 → 信号（3.3V 逻辑）", font=font(19), fill=INK)
    d.text((555, 907), "5V/2A 独立供电；必须与 X5 共地；硬限位", font=font(19), fill="#8F3027")
    arrow(d, (700, 735), (700, 805), ORANGE_DARK, 5)
    arrow(d, (390, 835), (520, 880), "#B84B3D", 5)

    rounded(d, (70, 975, 1730, 1050), "#EEF2F1", 20)
    center_text(
        d,
        (900, 1013),
        "带电禁止插拔 MIPI；屏幕与舵机按规格独立供电；上电默认回中；物理暂停键进入 SAFE_STOP。",
        font(21),
        INK,
    )
    image.save(RENDERS / "wiring.png", quality=95)


def make_build_card() -> None:
    w, h = 1800, 2545
    image = Image.new("RGB", (w, h), PAPER)
    d = ImageDraw.Draw(image)

    d.text((90, 80), "CookMate", font=font(68), fill=INK)
    d.text((92, 160), "48 小时实体 Demo 方案卡", font=font(39), fill=MUTED)
    rounded(d, (92, 230, 510, 286), ORANGE, 25)
    center_text(d, (301, 258), "RDK X5 · 工程样机", font(22), WHITE)

    d.text((90, 345), "不是自动炒菜机，而是做饭时的免手状态终端。", font=font(34), fill=ORANGE_DARK)
    d.text((90, 405), "用户在普通砧板和锅具旁亲手做饭；设备保存当前步骤、管理计时，\n通过语音与实体键控制进度，并用固定机位提供有限现场上下文。", font=font(27), fill=INK, spacing=9)

    # Product image crop.
    prod = Image.open(RENDERS / "engineering_prototype.png").convert("RGB")
    prod = prod.crop((35, 300, 1765, 1030))
    prod.thumbnail((1540, 650))
    image.paste(prod, ((1800 - prod.width) // 2, 505))

    d.text((90, 1195), "48 小时只交付这条闭环", font=font(39), fill=INK)
    stages = [
        ("01", "实体开机", "RDK X5 + 屏幕 + 三键"),
        ("02", "语音/按钮", "继续、重复、暂停、计时"),
        ("03", "云台观察", "相机在切配/锅具区间转动"),
        ("04", "安全降级", "遮挡、噪声、断网仍可继续"),
    ]
    for i, (num, title, sub) in enumerate(stages):
        x = 90 + i * 414
        rounded(d, (x, 1260, x + 372, 1430), "#F4EDE3" if i < 3 else ORANGE_PALE, 24, LINE, 3)
        d.text((x + 25, 1282), num, font=font(19), fill=ORANGE)
        d.text((x + 25, 1320), title, font=font(28), fill=INK)
        d.text((x + 25, 1368), sub, font=font(18), fill=MUTED)

    d.text((90, 1500), "可交付的实体证明", font=font(39), fill=INK)
    physical = [
        "① 打印件：底座托盘、屏幕斜托、立柱夹、舵机/相机架",
        "② 1:1 纸模板：确认屏幕、X5、按键和立柱孔位",
        "③ 接线图：USB 外设 + PWM 舵机 + 独立电源/共地",
        "④ 测试脚本：相机、声卡、PWM、状态机可逐项验机",
    ]
    for i, line in enumerate(physical):
        y = 1575 + i * 48
        d.text((120, y), line, font=font(23), fill=INK)

    d.text((90, 1815), "核心硬件参数", font=font(39), fill=INK)
    params = [
        ("主控", "RDK X5 8GB"),
        ("屏幕", "5.5 英寸 HDMI"),
        ("相机", "UVC 广角 + 单轴云台"),
        ("输入", "USB 麦克风 + HID 三键"),
        ("执行", "MG90S / Pin 33 PWM"),
        ("结构", "外露工程样机，先不封闭整壳"),
    ]
    for i, (k, v) in enumerate(params):
        row = i // 3
        col = i % 3
        x = 90 + col * 548
        y = 1880 + row * 155
        rounded(d, (x, y, x + 510, y + 125), "#F4EDE3", 18, LINE, 3)
        d.text((x + 22, y + 20), k, font=font(18), fill=MUTED)
        d.text((x + 22, y + 56), v, font=font(25), fill=INK)

    d.text((90, 2225), "证据状态", font=font(39), fill=INK)
    statuses = [
        ("Design package", "READY", GREEN),
        ("Desktop state demo", "READY", GREEN),
        ("RDK hardware test", "NOT YET", ORANGE_DARK),
        ("Physical assembly", "NOT YET", ORANGE_DARK),
    ]
    for i, (name, status, color) in enumerate(statuses):
        x = 90 + i * 414
        rounded(d, (x, 2290, x + 372, 2400), "#F4EDE3", 20, LINE, 3)
        d.text((x + 23, 2308), name, font=font(19), fill=INK)
        d.text((x + 23, 2349), status, font=font(20), fill=color)

    d.text((90, 2460), "官方可验证：RDK X5 规格 / Model Zoo / 音频 / PWM 官方资料", font=font(19), fill=MUTED)
    d.text((90, 2495), "待现场验证：外设兼容、厨房噪声、视觉 ROI、舵机供电、连续运行", font=font(19), fill=MUTED)
    image.save(RENDERS / "application_build_card.png", quality=95)


# --- STL generation -------------------------------------------------------

Point = tuple[float, float, float]
Triangle = tuple[Point, Point, Point]


def box_triangles(
    x0: float,
    y0: float,
    z0: float,
    x1: float,
    y1: float,
    z1: float,
) -> list[Triangle]:
    p = {
        "000": (x0, y0, z0),
        "100": (x1, y0, z0),
        "110": (x1, y1, z0),
        "010": (x0, y1, z0),
        "001": (x0, y0, z1),
        "101": (x1, y0, z1),
        "111": (x1, y1, z1),
        "011": (x0, y1, z1),
    }
    quads = [
        ("000", "010", "110", "100"),  # bottom
        ("001", "101", "111", "011"),  # top
        ("000", "100", "101", "001"),  # front y0
        ("010", "011", "111", "110"),  # back y1
        ("000", "001", "011", "010"),  # left x0
        ("100", "110", "111", "101"),  # right x1
    ]
    tris: list[Triangle] = []
    for a, b, c, d_ in quads:
        tris.append((p[a], p[b], p[c]))
        tris.append((p[a], p[c], p[d_]))
    return tris


def cylinder_triangles(
    cx: float,
    cy: float,
    z0: float,
    z1: float,
    radius: float,
    segments: int = 20,
) -> list[Triangle]:
    tris: list[Triangle] = []
    bottom_center = (cx, cy, z0)
    top_center = (cx, cy, z1)
    for i in range(segments):
        a0 = 2 * math.pi * i / segments
        a1 = 2 * math.pi * (i + 1) / segments
        p0 = (cx + radius * math.cos(a0), cy + radius * math.sin(a0), z0)
        p1 = (cx + radius * math.cos(a1), cy + radius * math.sin(a1), z0)
        q0 = (p0[0], p0[1], z1)
        q1 = (p1[0], p1[1], z1)
        tris.extend([(bottom_center, p1, p0), (top_center, q0, q1), (p0, p1, q1), (p0, q1, q0)])
    return tris


def write_stl(path: Path, triangles: list[Triangle], name: str) -> None:
    with path.open("wb") as f:
        header = f"CookMate quick-fit prototype: {name}".encode("ascii", "replace")[:80]
        f.write(header.ljust(80, b" "))
        f.write(struct.pack("<I", len(triangles)))
        for a, b, c in triangles:
            ux, uy, uz = b[0] - a[0], b[1] - a[1], b[2] - a[2]
            vx, vy, vz = c[0] - a[0], c[1] - a[1], c[2] - a[2]
            nx, ny, nz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
            length = math.sqrt(nx * nx + ny * ny + nz * nz) or 1
            normal = (nx / length, ny / length, nz / length)
            f.write(struct.pack("<12fH", *normal, *a, *b, *c, 0))


def make_stls() -> None:
    # Base tray: separate walls/floor shells. Inspect and scale after measuring parts.
    base: list[Triangle] = []
    base += box_triangles(0, 0, 0, 180, 135, 4)       # floor
    base += box_triangles(0, 0, 0, 180, 4, 36)        # front wall
    base += box_triangles(0, 131, 0, 180, 135, 36)    # rear wall
    base += box_triangles(0, 4, 0, 4, 131, 36)        # left wall
    base += box_triangles(176, 4, 0, 180, 131, 36)    # right wall
    for x, y in [(12, 12), (162, 12), (12, 118), (162, 118), (72, 34), (112, 34)]:
        base += cylinder_triangles(x, y, 4, 14, 3.2)
    write_stl(CAD / "01_base_tray.stl", base, "base tray")

    # Screen support frame.
    frame: list[Triangle] = []
    frame += box_triangles(0, 0, 0, 150, 10, 12)
    frame += box_triangles(0, 86, 0, 150, 96, 12)
    frame += box_triangles(0, 10, 0, 10, 86, 12)
    frame += box_triangles(140, 10, 0, 150, 86, 12)
    for x in (15, 135):
        for y in (15, 81):
            frame += cylinder_triangles(x, y, 10, 15, 2.5)
    write_stl(CAD / "02_screen_bezel.stl", frame, "screen bezel")

    # Adjustable mast clamp and servo cradle.
    mast: list[Triangle] = []
    mast += box_triangles(0, 0, 0, 34, 34, 5)
    mast += box_triangles(0, 0, 0, 5, 34, 86)
    mast += box_triangles(29, 0, 0, 34, 34, 86)
    mast += box_triangles(5, 0, 78, 29, 34, 86)
    write_stl(CAD / "03_mast_clamp.stl", mast, "mast clamp")

    cradle: list[Triangle] = []
    cradle += box_triangles(0, 0, 0, 52, 34, 4)
    cradle += box_triangles(0, 0, 0, 5, 34, 36)
    cradle += box_triangles(47, 0, 0, 52, 34, 36)
    cradle += box_triangles(5, 0, 32, 47, 8, 39)
    cradle += box_triangles(5, 26, 32, 47, 34, 39)
    write_stl(CAD / "04_servo_camera_cradle.stl", cradle, "servo camera cradle")

    # Front HID keypad bezel.
    bezel: list[Triangle] = []
    bezel += box_triangles(0, 0, 0, 96, 8, 9)
    bezel += box_triangles(0, 50, 0, 96, 58, 9)
    bezel += box_triangles(0, 8, 0, 8, 50, 9)
    bezel += box_triangles(88, 8, 0, 96, 50, 9)
    write_stl(CAD / "05_keypad_bezel.stl", bezel, "keypad bezel")


if __name__ == "__main__":
    RENDERS.mkdir(parents=True, exist_ok=True)
    CAD.mkdir(parents=True, exist_ok=True)
    make_product()
    make_exploded()
    make_wiring()
    make_build_card()
    make_stls()
    print("Generated hardware prototypes, build card, wiring diagram and STL fixtures.")
