# CookMate 本地状态演示

这是一个无第三方依赖的 Python 状态机原型。它用于验证：

- 菜谱步骤推进；
- 用户确认才推进；
- 暂停后计时冻结；
- 视觉事件不自动完成步骤；
- JSON 快照和 JSONL 日志。

它不代表已经完成 RDK 语音、视觉或舵机集成。

## 运行

```bash
cd runtime
python3 cookmate_state.py
```

命令：

```text
n  继续 / 下一步
r  重复
p  暂停 / 恢复
t  查询计时
v  模拟手离开操作区
prep 模拟手进入切配区
pan  模拟手进入锅具区
q  退出
```

自动烟测：

```bash
python3 cookmate_state.py --script "n,prep,pan,p,t,p,v,n,n,n,n,n"
```

运行后会生成：

```text
logs/events.jsonl
logs/session.json
```

## RDK 上的下一步

1. 将“n/r/p/t/v”接到按钮、ASR 意图或视觉事件；
2. 接 HDMI 状态页；
3. 接相机云台舵机；
4. 断电重启后加载最后快照；
5. 现场必须测试遮挡、断网、拔相机和声卡失败。

状态机通过并不等于机器人已经完成；硬件证据需要另外保存。
