#!/usr/bin/env python3
"""Minimal hardware-ready CookMate state demo.

This program does not infer doneness. It proves the local recipe state, timer,
button/voice-intent interface and recovery contract on a desktop or RDK X5.
"""

from __future__ import annotations

import argparse
import json
import os
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
DEFAULT_RECIPE = ROOT / "recipes" / "tomato_egg.json"
DEFAULT_LOG = ROOT / "logs"


def iso_now() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


@dataclass
class Session:
    recipe: dict[str, Any]
    step_index: int = 0
    paused: bool = False
    completed: bool = False
    muted: bool = False
    remaining_s: float | None = None
    timer_end: float | None = None
    last_confirmed_at: str | None = None
    pending_vision_hint: bool = False
    zone: str = "PREP"
    events: list[dict[str, Any]] = field(default_factory=list)

    def __post_init__(self) -> None:
        if self.timer_end is None:
            self.reset_timer()

    @property
    def step(self) -> dict[str, Any]:
        return self.recipe["steps"][self.step_index]

    @property
    def total(self) -> int:
        return len(self.recipe["steps"])

    def reset_timer(self) -> None:
        duration = self.step.get("timer_s")
        self.remaining_s = float(duration) if duration else None
        self.timer_end = time.monotonic() + self.remaining_s if self.remaining_s and not self.paused else None

    def update_timer(self) -> None:
        if self.timer_end is None:
            return
        self.remaining_s = max(0.0, self.timer_end - time.monotonic())
        if self.remaining_s == 0:
            self.timer_end = None

    def log(self, event: str, payload: dict[str, Any] | None = None) -> None:
        entry = {
            "event": event,
            "at": iso_now(),
            "step": self.step_index,
            "phase": self.phase(),
        }
        if payload:
            entry["payload"] = payload
        self.events.append(entry)

    def phase(self) -> str:
        if self.completed:
            return "completed"
        if self.paused:
            return "paused"
        if self.remaining_s and self.remaining_s > 0:
            return "timer_running"
        return "awaiting_user_confirm"

    def next_step(self) -> str:
        if self.completed:
            return "本次流程已经完成。"
        if self.paused:
            return "当前暂停。先恢复，再继续下一步。"
        self.log("USER_NEXT")
        self.last_confirmed_at = iso_now()
        if self.step_index >= self.total - 1:
            self.completed = True
            self.paused = False
            self.timer_end = None
            self.remaining_s = None
            return f"完成 {self.recipe['title']}。共用 {self.total} 个步骤，时间请用户确认。"
        self.step_index += 1
        self.paused = False
        self.pending_vision_hint = False
        self.reset_timer()
        return f"第 {self.step_index + 1} 步，{self.step['short']}。{self.step['prompt']}"

    def repeat(self) -> str:
        self.log("USER_REPEAT")
        return f"第 {self.step_index + 1} 步，{self.step['short']}。{self.step['prompt']}"

    def toggle_pause(self) -> str:
        if self.completed:
            return "流程已完成。"
        if self.paused:
            self.paused = False
            if self.remaining_s is not None and self.remaining_s > 0:
                self.timer_end = time.monotonic() + self.remaining_s
            self.log("USER_RESUME")
            return "已恢复。屏幕、语音和计时回到暂停前状态。"
        self.update_timer()
        self.paused = True
        self.timer_end = None
        self.log("USER_PAUSE")
        return "已暂停。计时冻结，语音停止，舵机回安全位。"

    def query_timer(self) -> str:
        self.update_timer()
        if self.remaining_s is None:
            return "当前步骤没有活动计时。"
        if self.paused:
            return f"当前暂停，计时冻结在 {format_time(self.remaining_s)}。"
        return f"计时还剩 {format_time(self.remaining_s)}。"

    def vision_out(self) -> str:
        if self.completed or self.paused:
            return "当前状态不接受视觉推进。"
        self.pending_vision_hint = True
        self.zone = "CENTER"
        self.log("VISION_USER_OUT", {"auto_advance": False})
        return "用户的手离开操作区。如果这一步完成，请按继续；未完成请按暂停/等我。"

    def set_zone(self, zone: str) -> str:
        if self.completed or self.paused:
            return "暂停或完成状态下，相机云台不追手。"
        normalized = zone.upper()
        if normalized not in {"PREP", "PAN"}:
            return "未知操作区，不移动相机。"
        self.zone = normalized
        self.log("VISION_ZONE", {"zone": normalized, "auto_advance": False})
        label = "切配区" if normalized == "PREP" else "锅具区"
        return f"检测到手腕进入{label}，相机云台转向该区；步骤不会自动变化。"

    def tick(self) -> str | None:
        if self.completed or self.paused:
            return None
        before = self.remaining_s
        self.update_timer()
        if before and before > 0 and self.remaining_s == 0:
            self.log("TIMER_EXPIRED", {"requires_user_confirm": True})
            return "计时结束。请检查现场状态，再决定是否继续。"
        return None

    def snapshot(self) -> dict[str, Any]:
        self.update_timer()
        return {
            "version": 1,
            "recipe_id": self.recipe["id"],
            "step_index": self.step_index,
            "step_id": self.step["id"],
            "phase": self.phase(),
            "paused": self.paused,
            "completed": self.completed,
            "muted": self.muted,
            "remaining_s": round(self.remaining_s, 3) if self.remaining_s is not None else None,
            "last_confirmed_at": self.last_confirmed_at,
            "pending_vision_hint": self.pending_vision_hint,
            "zone": self.zone,
            "saved_at": iso_now(),
        }


def format_time(seconds: float) -> str:
    value = max(0, int(seconds))
    return f"{value // 60:02d}:{value % 60:02d}"


def save_atomic(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def append_events(path: Path, events: list[dict[str, Any]]) -> None:
    if not events:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        for event in events:
            handle.write(json.dumps(event, ensure_ascii=False) + "\n")
    events.clear()


def print_status(session: Session, message: str | None = None) -> None:
    if message:
        print(message)
    timer = format_time(session.remaining_s) if session.remaining_s is not None else "--:--"
    print(
        f"[{session.step_index + 1}/{session.total}] "
        f"{session.step['short']} | {session.phase()} | {timer}"
    )


def apply_command(session: Session, command: str) -> str:
    cmd = command.strip().lower()
    if cmd in {"n", "next", "继续", "下一步", "好了", "完成"}:
        return session.next_step()
    if cmd in {"r", "repeat", "重复", "再说一遍", "没听清"}:
        return session.repeat()
    if cmd in {"p", "pause", "暂停", "等我", "等一下", "继续做饭"}:
        return session.toggle_pause()
    if cmd in {"t", "timer", "还有多久", "剩多久", "时间"}:
        return session.query_timer()
    if cmd in {"v", "vision", "手离开"}:
        return session.vision_out()
    if cmd in {"prep", "切配", "切配区"}:
        return session.set_zone("PREP")
    if cmd in {"pan", "锅具", "锅具区"}:
        return session.set_zone("PAN")
    return "未知事件，不改变步骤。请使用继续、重复、暂停、计时或手离开。"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--recipe", type=Path, default=DEFAULT_RECIPE)
    parser.add_argument("--log-dir", type=Path, default=DEFAULT_LOG)
    parser.add_argument("--script", default=None, help="Comma-separated event smoke test")
    args = parser.parse_args()

    recipe = json.loads(args.recipe.read_text(encoding="utf-8"))
    session = Session(recipe=recipe)
    print(f"CookMate local state demo: {recipe['title']}")
    print_status(session, f"第 1 步，{session.step['short']}。{session.step['prompt']}")

    commands = [x.strip() for x in args.script.split(",") if x.strip()] if args.script else None
    try:
        while True:
            if commands is not None:
                if not commands:
                    break
                raw = commands.pop(0)
            else:
                raw = input("command [n/r/p/t/v/q] > ")
            if raw in {"q", "quit", "退出"}:
                break
            message = apply_command(session, raw)
            print_status(session, message)
            append_events(args.log_dir / "events.jsonl", session.events)
            save_atomic(args.log_dir / "session.json", session.snapshot())
            if commands is None:
                time.sleep(0.05)
            else:
                tick = session.tick()
                if tick:
                    print(tick)
    except (EOFError, KeyboardInterrupt):
        print()
    finally:
        append_events(args.log_dir / "events.jsonl", session.events)
        save_atomic(args.log_dir / "session.json", session.snapshot())
        print("State saved to", args.log_dir / "session.json")


if __name__ == "__main__":
    main()
